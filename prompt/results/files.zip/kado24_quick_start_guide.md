# Kado24 Cambodia - Quick Start Guide for Cursor AI

## 🚀 Getting Started

This quick reference guide contains the most essential prompts to start developing Kado24 immediately. For complete details, refer to the full development guide.

---

## Phase 0: Initial Setup (Day 1)

### 1. Project Structure Creation
Use this prompt in Cursor AI to create the complete project structure:

```
Create a production-ready Maven multi-module project structure for Kado24 Cambodia with:
- Parent POM with Spring Boot 3.2, Java 17
- 12 microservice modules (auth, user, voucher, order, payment, wallet, redemption, merchant, admin, notification, payout, analytics)
- Common module for shared components
- Docker Compose for local infrastructure (PostgreSQL 17, Redis 7, Kafka 3.x, APISIX 3.7)
- Follow clean architecture pattern
- Include Dockerfile for each service
- Add comprehensive .gitignore
```

### 2. Database Setup
```
Create PostgreSQL 17 database schema for Kado24 with:
- 4 schemas: auth_schema, core_schema, business_schema, audit_schema
- OAuth2 tables (clients, tokens, authorizations)
- Core tables (users, user_profiles, merchants, merchant_details)
- Business tables (vouchers, voucher_inventory, orders, payments, wallet_vouchers, redemptions)
- Audit tables (event_log, activity_log)
- Proper indexes, constraints, and partitioning
- Include init.sql script for Docker
```

---

## Phase 1: Core Backend (Days 2-7)

### 3. Authentication Service
```
Create production-ready OAuth2 Authorization Server (Port 8081) with:
- Spring Security OAuth2 Authorization Server
- JWT tokens with 1-hour access, 30-day refresh
- Support for: authorization_code, refresh_token, password grant types
- Endpoints: /oauth2/register, /oauth2/login, /oauth2/token, /oauth2/verify-email
- BCrypt password hashing, account lockout after 5 attempts
- Token introspection for API Gateway
- Comprehensive error handling and logging
```

### 4. User Service
```
Create User Profile Service (Port 8082) with:
- User profile CRUD operations
- Avatar upload with image processing (resize to 400x400)
- File storage in /var/kado24/uploads/avatars/
- Redis caching (TTL: 1 hour)
- Full-text search on user profiles
- Admin endpoints for user management
- Kafka events: user-profile-updated
```

### 5. Voucher Service
```
Create Voucher Service (Port 8083) with:
- Public endpoints: GET /vouchers (with filters), GET /vouchers/{id}, search
- Merchant endpoints: POST, PUT vouchers, submit for approval
- Admin endpoints: approve/reject vouchers
- PostgreSQL full-text search (tsvector)
- Inventory management with pessimistic locking
- Redis caching (voucher details: 30min, lists: 5min)
- Scheduled jobs: auto-expire vouchers, send expiry alerts
```

### 6. Order & Payment Services
```
Create Order Service (Port 8084) with:
- Order creation with 15-minute reservation timeout
- Commission calculation (8% platform, 92% merchant)
- Order state machine: PENDING → PAID → COMPLETED/CANCELLED
- Kafka events for order lifecycle
- Distributed locking with Redis
- Table partitioning by month

Create Payment Service (Port 8085) with:
- Integration with ABA Pay, Wing, Pi Pay, KHQR
- Payment initiation, callback handling, status polling
- Signature verification for gateway callbacks
- Support for redirect and QR code payment flows
- Retry logic with exponential backoff
- Mock payment gateways for development
```

---

## Phase 2: Mobile App (Days 8-14)

### 7. Flutter Consumer App Setup
```
Create Flutter Consumer App with:
- Clean Architecture (data, domain, presentation layers)
- BLoC state management
- Dio for networking with interceptors
- FlutterSecureStorage for tokens
- Dependencies: flutter_bloc, dio, cached_network_image, qr_flutter, mobile_scanner
- Features: Auth, Home, Vouchers, Cart, Checkout, Payment, Wallet
- Support for 30+ screens as per wireframes
```

### 8. Authentication Flow
```
Implement authentication feature with:
- Login screen (email/phone + password)
- Sign up screen with validation
- OTP verification (6-digit, auto-advance)
- Social login (Facebook, Google, Apple)
- Forgot password flow
- Token management with auto-refresh
- Dio interceptor for auth headers
- Secure storage for tokens
```

### 9. Voucher Discovery & Purchase
```
Implement voucher features with:
- Home screen with featured vouchers, categories, banners
- Voucher list with filters (category, price range, search)
- Voucher detail screen with image carousel, reviews
- Search with debouncing (500ms)
- Cart management (persist locally with Hive)
- Checkout flow with gift option
- Payment WebView integration
- Order confirmation screen
```

### 10. Digital Wallet
```
Implement wallet feature with:
- Wallet screen (tabs: Active, Redeemed, Expired, Gifted)
- Full-screen QR code display with PIN
- Auto-increase screen brightness for scanning
- Gift voucher flow (select recipient from contacts or manual entry)
- QR code generation with ZXing
- Expiry countdown timers
- Offline voucher caching
```

---

## Phase 3: Merchant App (Days 15-18)

### 11. Flutter Merchant App
```
Create Flutter Merchant App with:
- Dashboard (today's sales, pending redemptions)
- QR scanner for redemption
- Voucher management (create, edit, view analytics)
- Redemption validation (QR signature verification)
- Offline mode support (sync when online)
- Sales reports and payout tracking
- Package: mobile_scanner for QR scanning
```

---

## Phase 4: Admin Portal (Days 19-23)

### 12. Angular Admin Portal
```
Create Angular 17 Admin Portal with:
- Dashboard with real-time analytics
- Merchant approval workflow
- Voucher moderation (approve/reject)
- User management (view, suspend, ban)
- Order monitoring
- Financial reports (revenue, commissions, payouts)
- Angular Material for UI
- Chart.js for data visualization
- Lazy loading for all feature modules
```

---

## Phase 5: Integration & Testing (Days 24-28)

### 13. Kafka Event Streaming
```
Implement Kafka integration with:
- Topics: order-events, payment-events, notification-events, redemption-events
- Event producers in Order, Payment, Redemption services
- Event consumers in Wallet, Notification, Analytics services
- Manual acknowledgment for at-least-once delivery
- Dead letter queues for failed messages
- Idempotency checks to prevent duplicate processing
```

### 14. Comprehensive Testing
```
Implement testing strategy with:
- Unit tests with Mockito (70% of tests)
- Integration tests with TestContainers (PostgreSQL, Kafka, Redis)
- Repository tests with @DataJpaTest
- Flutter widget tests and BLoC tests
- E2E tests with REST Assured
- Load tests with Gatling or JMeter
- Target: >80% code coverage
- Jacoco for coverage reports
```

---

## Phase 6: Deployment (Days 29-30)

### 15. Docker & Kubernetes
```
Create Kubernetes manifests with:
- Namespace: kado24-prod
- Deployments for all 12 microservices
- StatefulSets for PostgreSQL, Redis, Kafka
- Services (ClusterIP)
- Ingress with TLS (Let's Encrypt)
- HPA (Horizontal Pod Autoscaler) for auto-scaling
- ConfigMaps and Secrets for configuration
- Prometheus + Grafana for monitoring
- Resource limits: requests and limits for all pods
```

---

## Essential Commands

### Development
```bash
# Start local infrastructure
docker-compose up -d

# Run Spring Boot service
mvn spring-boot:run

# Run Flutter app
flutter run

# Run Angular app
ng serve

# Run tests
mvn test
flutter test
ng test
```

### Deployment
```bash
# Build Docker images
docker build -t kado24/auth-service:latest ./kado24-auth-service

# Deploy to Kubernetes
kubectl apply -f kubernetes/
kubectl rollout status deployment/auth-service -n kado24-prod

# Check logs
kubectl logs -f <pod-name> -n kado24-prod
```

---

## Critical Configuration

### Spring Boot application.yml
```yaml
spring:
  datasource:
    url: jdbc:postgresql://localhost:5432/kado24_db
    username: kado24_user
    password: ${POSTGRES_PASSWORD}
  
  kafka:
    bootstrap-servers: localhost:9092
  
  redis:
    host: localhost
    port: 6379

server:
  port: 808X  # Service-specific port
```

### Flutter Environment Config
```dart
// config/api_config.dart
class ApiConfig {
  static const String baseUrl = 'http://localhost:9080';
  static const String authUrl = '$baseUrl/oauth2';
  static const String apiUrl = '$baseUrl/api/v1';
}
```

### API Gateway Routes (APISIX)
```yaml
routes:
  - uri: /oauth2/*
    upstream:
      nodes:
        auth-service:8081: 1
  
  - uri: /api/v1/users/*
    upstream:
      nodes:
        user-service:8082: 1
    plugins:
      oauth2: {}
```

---

## Troubleshooting

### Common Issues

1. **Database Connection Failed**
   - Check PostgreSQL is running: `docker ps`
   - Verify credentials in application.yml
   - Check network connectivity

2. **Kafka Messages Not Consumed**
   - Verify topic exists: `kafka-topics --list`
   - Check consumer group: `kafka-consumer-groups --describe`
   - Ensure consumer is running

3. **Flutter Build Failed**
   - Run `flutter clean`
   - Delete `pubspec.lock` and run `flutter pub get`
   - Check Flutter version: `flutter --version`

4. **Payment Gateway Error**
   - Verify API keys in secrets
   - Check gateway sandbox environment
   - Review callback URL configuration

---

## Next Steps

1. Follow prompts sequentially
2. Test each component thoroughly before moving to next
3. Commit code frequently with meaningful messages
4. Document API endpoints with Swagger
5. Monitor application logs during development
6. Use Postman/Insomnia for API testing

---

## Resources

- **Full Development Guide**: See complete_development_guide.md
- **Wireframes**: kado24_wireframes.html (65+ screens)
- **Business Flows**: kado24_business_flow_diagrams.html
- **Architecture**: kado24_system_architecture.md

---

**Ready to build Kado24 Cambodia! 🚀**

Start with Phase 0, and use these prompts in Cursor AI for guided development. Each prompt is production-ready and follows best practices.
