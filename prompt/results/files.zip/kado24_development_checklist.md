# Kado24 Cambodia - Development Checklist

Track your progress as you build the Kado24 platform using Cursor AI.

---

## Phase 0: Foundation & Setup

### Project Structure
- [ ] Create Maven multi-module project
- [ ] Set up parent POM with dependency management
- [ ] Create 12 microservice modules
- [ ] Create kado24-common module
- [ ] Set up .gitignore files
- [ ] Create README.md with architecture overview

### Infrastructure
- [ ] Docker Compose configuration
- [ ] PostgreSQL 17 container
- [ ] Redis 7 container
- [ ] Apache Kafka 3.x + Zookeeper
- [ ] etcd for APISIX service discovery
- [ ] Apache APISIX 3.7 gateway
- [ ] Prometheus container
- [ ] Grafana container

### Database
- [ ] Create database schemas (auth, core, business, audit)
- [ ] Create OAuth2 tables
- [ ] Create user tables
- [ ] Create merchant tables
- [ ] Create voucher tables
- [ ] Create order & payment tables
- [ ] Create wallet & redemption tables
- [ ] Create audit tables
- [ ] Add indexes and constraints
- [ ] Set up table partitioning
- [ ] Create init.sql script

---

## Phase 1: Core Backend Services

### Common Module (kado24-common)
- [ ] BaseEntity with audit fields
- [ ] Common DTOs (ApiResponse, PageResponse, ErrorResponse)
- [ ] Enums (all 10+ enums)
- [ ] Custom exceptions (5+ exception classes)
- [ ] Utility classes (QRCodeUtil, ValidationUtil, etc.)
- [ ] Kafka event DTOs

### Auth Service (Port 8081)
- [ ] OAuth2 Authorization Server configuration
- [ ] User entity and repository
- [ ] Registration endpoint
- [ ] Login endpoint
- [ ] Token generation & refresh
- [ ] Email verification
- [ ] Password reset flow
- [ ] Token introspection for APISIX
- [ ] Account lockout mechanism
- [ ] Unit tests (>80% coverage)
- [ ] Integration tests

### User Service (Port 8082)
- [ ] User profile entity and repository
- [ ] Get profile endpoint
- [ ] Update profile endpoint
- [ ] Avatar upload endpoint
- [ ] Image processing (resize, optimize)
- [ ] Preferences management
- [ ] User search functionality
- [ ] Admin user management endpoints
- [ ] Redis caching implementation
- [ ] Kafka event publishing
- [ ] Unit tests
- [ ] Integration tests with TestContainers

### Voucher Service (Port 8083)
- [ ] Voucher entity and repository
- [ ] VoucherInventory entity
- [ ] Category management
- [ ] Public voucher listing (with filters)
- [ ] Voucher detail endpoint
- [ ] Search functionality (full-text)
- [ ] Merchant voucher CRUD
- [ ] Voucher approval workflow
- [ ] Image upload for vouchers
- [ ] Inventory management with locking
- [ ] Redis caching strategy
- [ ] Scheduled jobs (expiry, alerts)
- [ ] Unit tests
- [ ] Integration tests
- [ ] Concurrency tests for inventory

### Order Service (Port 8084)
- [ ] Order entity and repository
- [ ] Order creation with validation
- [ ] Commission calculation logic
- [ ] Order state machine implementation
- [ ] Order cancellation flow
- [ ] Merchant order endpoints
- [ ] Admin order monitoring
- [ ] Distributed locking (Redis)
- [ ] Order expiration job (15 min)
- [ ] Table partitioning by month
- [ ] Kafka event publishing
- [ ] Unit tests
- [ ] Integration tests
- [ ] Saga pattern implementation

### Payment Service (Port 8085)
- [ ] Payment entity and repository
- [ ] Payment gateway abstraction
- [ ] ABA PayWay integration
- [ ] Wing Money integration
- [ ] Pi Pay integration
- [ ] KHQR integration
- [ ] Payment initiation endpoint
- [ ] Callback endpoints (all gateways)
- [ ] Payment status polling
- [ ] Refund functionality
- [ ] Signature verification
- [ ] Mock payment gateway (dev)
- [ ] Retry logic with backoff
- [ ] Unit tests
- [ ] Integration tests
- [ ] Security tests

### Wallet Service (Port 8086)
- [ ] WalletVoucher entity
- [ ] QR code generation (ZXing)
- [ ] PIN code generation
- [ ] Voucher activation (Kafka consumer)
- [ ] Wallet listing endpoints
- [ ] QR code display endpoint
- [ ] Gift voucher flow
- [ ] Claim gift endpoint
- [ ] Expiry management
- [ ] Redis QR caching
- [ ] Scheduled expiry checks
- [ ] Unit tests
- [ ] Integration tests

### Redemption Service (Port 8087)
- [ ] Redemption entity
- [ ] QR validation logic
- [ ] PIN validation logic
- [ ] Merchant validation
- [ ] Redemption endpoint
- [ ] Validation endpoint (preview)
- [ ] Redemption history
- [ ] Distributed locking
- [ ] Fraud detection logging
- [ ] Admin reversal endpoint
- [ ] Unit tests
- [ ] Integration tests
- [ ] Security tests

### Merchant Service (Port 8088)
- [ ] Merchant entity
- [ ] Merchant registration
- [ ] Verification workflow
- [ ] Merchant dashboard stats
- [ ] Bank info management
- [ ] Location management
- [ ] Admin approval endpoints
- [ ] Payout calculation
- [ ] Unit tests
- [ ] Integration tests

### Notification Service (Port 8091)
- [ ] Notification entity
- [ ] Email service (SendGrid)
- [ ] SMS service
- [ ] Push notification (FCM)
- [ ] Kafka event consumers
- [ ] Template management
- [ ] Notification preferences
- [ ] Delivery tracking
- [ ] Unit tests
- [ ] Integration tests

### Payout Service (Port 8092)
- [ ] Payout entity
- [ ] Weekly payout calculation
- [ ] Bank transfer integration
- [ ] Payout schedule job
- [ ] Merchant payout history
- [ ] Admin payout management
- [ ] Unit tests
- [ ] Integration tests

### Analytics Service (Port 8093)
- [ ] Analytics aggregation
- [ ] Kafka Streams processing
- [ ] Report generation
- [ ] Dashboard statistics API
- [ ] Revenue calculations
- [ ] Merchant performance metrics
- [ ] Unit tests
- [ ] Integration tests

### Admin Backend (Port 8089)
- [ ] Dashboard statistics API
- [ ] Merchant approval endpoints
- [ ] Voucher moderation endpoints
- [ ] User management endpoints
- [ ] Order monitoring endpoints
- [ ] Financial reports
- [ ] Platform settings
- [ ] Unit tests
- [ ] Integration tests

---

## Phase 2: API Gateway

### Apache APISIX Configuration
- [ ] Route definitions (all 12 services)
- [ ] OAuth2 plugin configuration
- [ ] Rate limiting plugin
- [ ] CORS plugin
- [ ] Circuit breaker configuration
- [ ] Request/response transformation
- [ ] Prometheus metrics plugin
- [ ] Service discovery (etcd)
- [ ] Health checks
- [ ] Load balancing setup
- [ ] SSL/TLS configuration
- [ ] Testing all routes

---

## Phase 3: Mobile Applications

### Flutter Consumer App (30+ screens)

#### Setup
- [ ] Project structure (Clean Architecture)
- [ ] BLoC state management setup
- [ ] Dio networking configuration
- [ ] Secure storage for tokens
- [ ] Hive for local storage
- [ ] Navigation setup (go_router)
- [ ] Theme configuration
- [ ] Internationalization (EN/KH)

#### Authentication Feature
- [ ] Splash screen
- [ ] Onboarding screens (3 pages)
- [ ] Login screen
- [ ] Sign up screen
- [ ] OTP verification screen
- [ ] Forgot password screen
- [ ] Social login integration
- [ ] Auth BLoC implementation
- [ ] Token management
- [ ] Widget tests

#### Home & Discovery
- [ ] Home screen with sections
- [ ] Banner carousel
- [ ] Category list
- [ ] Featured vouchers grid
- [ ] Voucher list screen
- [ ] Voucher detail screen
- [ ] Search screen
- [ ] Filter bottom sheet
- [ ] Sort bottom sheet
- [ ] Widget tests

#### Cart & Checkout
- [ ] Cart screen
- [ ] Cart item card
- [ ] Cart summary
- [ ] Checkout screen
- [ ] Gift recipient form
- [ ] Order summary
- [ ] Payment method screen
- [ ] Payment WebView
- [ ] Order confirmation
- [ ] Widget tests

#### Wallet & QR
- [ ] Wallet screen (4 tabs)
- [ ] Wallet voucher card
- [ ] Full-screen QR display
- [ ] PIN display
- [ ] Gift voucher screen
- [ ] Claim gift screen
- [ ] Redemption history
- [ ] Expiry indicators
- [ ] Widget tests

#### Profile & Settings
- [ ] Profile screen
- [ ] Edit profile screen
- [ ] Avatar upload
- [ ] Settings screen
- [ ] Preferences screen
- [ ] Order history
- [ ] Notifications screen
- [ ] Help & support
- [ ] Widget tests

#### Testing
- [ ] Unit tests for BLoCs
- [ ] Unit tests for repositories
- [ ] Widget tests for all screens
- [ ] Integration tests for flows
- [ ] Golden tests for UI consistency

### Flutter Merchant App (20+ screens)

#### Setup
- [ ] Project structure
- [ ] BLoC state management
- [ ] QR scanner integration
- [ ] Offline mode setup

#### Core Features
- [ ] Login/registration
- [ ] Dashboard screen
- [ ] QR scanner screen
- [ ] Redemption validation
- [ ] Voucher management
- [ ] Create voucher screen
- [ ] Sales reports
- [ ] Payout tracking
- [ ] Offline sync
- [ ] Widget tests

---

## Phase 4: Admin Portal

### Angular Admin Portal (15+ screens)

#### Setup
- [ ] Angular 17 project
- [ ] Angular Material setup
- [ ] Routing configuration
- [ ] Auth guard implementation
- [ ] HTTP interceptors
- [ ] Environment configuration

#### Core Features
- [ ] Login screen
- [ ] Dashboard with analytics
- [ ] Metric cards
- [ ] Revenue chart (Chart.js)
- [ ] Order statistics chart
- [ ] Recent transactions table
- [ ] Top merchants table
- [ ] Alerts panel

#### Merchant Management
- [ ] Merchant list
- [ ] Merchant detail view
- [ ] Approval workflow
- [ ] Verification documents
- [ ] Merchant suspension

#### Voucher Moderation
- [ ] Pending vouchers list
- [ ] Voucher detail review
- [ ] Approve/reject actions
- [ ] Moderation history

#### User Management
- [ ] User list with search
- [ ] User detail view
- [ ] Suspend/ban actions
- [ ] User activity log

#### Financial Reports
- [ ] Revenue dashboard
- [ ] Commission reports
- [ ] Payout management
- [ ] Transaction monitoring

#### Testing
- [ ] Unit tests for services
- [ ] Component tests
- [ ] E2E tests with Protractor

---

## Phase 5: Integrations

### Kafka Event Streaming
- [ ] Kafka configuration (all services)
- [ ] Producer implementation
- [ ] Consumer implementation
- [ ] Event models (DTOs)
- [ ] Dead letter queues
- [ ] Error handling
- [ ] Monitoring setup
- [ ] Integration tests

### External Services
- [ ] ABA PayWay integration
- [ ] Wing Money integration
- [ ] Pi Pay integration
- [ ] KHQR integration
- [ ] Firebase FCM setup
- [ ] SendGrid email setup
- [ ] SMS gateway integration
- [ ] Facebook Login
- [ ] Google Sign-In
- [ ] Apple Sign In

---

## Phase 6: Testing

### Backend Testing
- [ ] Unit tests (all services, >80% coverage)
- [ ] Integration tests with TestContainers
- [ ] Repository tests
- [ ] API tests with REST Assured
- [ ] Security tests
- [ ] Performance tests (Gatling/JMeter)
- [ ] Concurrency tests
- [ ] Kafka integration tests

### Frontend Testing
- [ ] Flutter unit tests
- [ ] Flutter widget tests
- [ ] Flutter integration tests
- [ ] Angular unit tests
- [ ] Angular component tests
- [ ] E2E tests

### System Testing
- [ ] End-to-end purchase flow
- [ ] End-to-end redemption flow
- [ ] End-to-end gift flow
- [ ] Load testing (1000+ concurrent users)
- [ ] Stress testing
- [ ] Security penetration testing

---

## Phase 7: Deployment

### Docker
- [ ] Dockerfile for each service
- [ ] Multi-stage builds
- [ ] Image optimization
- [ ] Docker Compose (dev environment)
- [ ] Docker registry setup

### Kubernetes
- [ ] Namespace creation
- [ ] ConfigMaps
- [ ] Secrets
- [ ] Deployments (all services)
- [ ] Services (ClusterIP)
- [ ] StatefulSets (DB, Redis, Kafka)
- [ ] Ingress with TLS
- [ ] Horizontal Pod Autoscaler
- [ ] Persistent Volume Claims
- [ ] Network policies

### CI/CD
- [ ] GitHub Actions / GitLab CI setup
- [ ] Build pipeline
- [ ] Test pipeline
- [ ] Code quality checks (SonarQube)
- [ ] Security scanning
- [ ] Docker image build & push
- [ ] Kubernetes deployment
- [ ] Rollback strategy

### Monitoring & Logging
- [ ] Prometheus setup
- [ ] Grafana dashboards
- [ ] ELK stack (Elasticsearch, Logstash, Kibana)
- [ ] Application logging (SLF4J)
- [ ] Distributed tracing (Jaeger/Zipkin)
- [ ] Error tracking (Sentry)
- [ ] Alerting rules
- [ ] Health check endpoints

---

## Phase 8: Production Readiness

### Security
- [ ] HTTPS everywhere
- [ ] OAuth2 token security
- [ ] API rate limiting
- [ ] SQL injection prevention
- [ ] XSS prevention
- [ ] CSRF protection
- [ ] Security headers
- [ ] Dependency vulnerability scanning
- [ ] Secrets management (HashiCorp Vault)

### Performance
- [ ] Database query optimization
- [ ] Index optimization
- [ ] Connection pooling
- [ ] Redis caching implementation
- [ ] CDN for static assets
- [ ] Image optimization
- [ ] Lazy loading (frontend)
- [ ] Code splitting (frontend)

### Reliability
- [ ] Database backups (automated)
- [ ] Disaster recovery plan
- [ ] High availability setup (replicas)
- [ ] Circuit breakers
- [ ] Retry mechanisms
- [ ] Graceful degradation
- [ ] Blue-green deployment

### Documentation
- [ ] API documentation (Swagger/OpenAPI)
- [ ] Architecture documentation
- [ ] Deployment guide
- [ ] Operations runbook
- [ ] Developer onboarding guide
- [ ] User manuals (Consumer, Merchant, Admin)

---

## Final Checklist

### Pre-Launch
- [ ] All features implemented and tested
- [ ] Security audit completed
- [ ] Performance testing passed
- [ ] Load testing passed (target: 10,000 users)
- [ ] Staging environment deployed
- [ ] Production environment deployed
- [ ] Monitoring & alerting active
- [ ] Backup & restore tested
- [ ] Disaster recovery tested
- [ ] Documentation complete

### Launch Day
- [ ] Database migration successful
- [ ] All services healthy
- [ ] Mobile apps published (App Store, Google Play)
- [ ] Admin portal accessible
- [ ] Payment gateways verified (live credentials)
- [ ] Support team trained
- [ ] Marketing materials ready
- [ ] User communication sent

### Post-Launch
- [ ] Monitor system health (24/7 for first week)
- [ ] User feedback collection
- [ ] Bug fixes prioritized
- [ ] Performance optimization
- [ ] Feature requests collected
- [ ] Weekly releases planned

---

## Progress Tracking

**Total Tasks:** 400+
**Completed:** _____
**In Progress:** _____
**Blocked:** _____

**Current Phase:** _____
**Target Completion:** _____
**Actual Completion:** _____

---

## Notes & Issues

Use this space to track blockers, decisions, and important notes:

```
Date: _________
Issue: _________
Resolution: _________

Date: _________
Issue: _________
Resolution: _________
```

---

**Remember:** Check off items as you complete them. This is your roadmap to a successful Kado24 launch! 🚀
