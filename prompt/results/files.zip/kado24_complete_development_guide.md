# Kado24 Cambodia - Complete Cursor AI Development Guide
## 🎯 Production-Ready Step-by-Step Development Prompts

---

## 📋 Table of Contents
1. [Development Environment Setup](#phase-0-development-environment-setup)
2. [Foundation & Infrastructure](#phase-1-foundation--infrastructure)
3. [Core Backend Services](#phase-2-core-backend-services)
4. [Mobile Applications (Flutter)](#phase-3-mobile-applications)
5. [Admin Portal](#phase-4-admin-portal)
6. [Integrations & Testing](#phase-5-integrations--testing)
7. [Production Deployment](#phase-6-production-deployment)

---

## PHASE 0: Development Environment Setup

### Prompt 0.1: Project Structure Creation
```
Create a production-ready Maven multi-module project structure for Kado24 Cambodia microservices platform:

Project Root: kado24-platform/
├── pom.xml (Parent POM with Spring Boot 3.2.x, Java 17)
├── kado24-common/ (Shared utilities, DTOs, constants)
├── kado24-auth-service/ (Port 8081 - OAuth2 Authorization Server)
├── kado24-user-service/ (Port 8082 - User profile management)
├── kado24-voucher-service/ (Port 8083 - Voucher CRUD & search)
├── kado24-order-service/ (Port 8084 - Order processing)
├── kado24-payment-service/ (Port 8085 - Payment gateway integration)
├── kado24-wallet-service/ (Port 8086 - Digital wallet & QR codes)
├── kado24-redemption-service/ (Port 8087 - Voucher redemption)
├── kado24-merchant-service/ (Port 8088 - Merchant management)
├── kado24-admin-backend/ (Port 8089 - Admin portal API)
├── kado24-notification-service/ (Port 8091 - Push/SMS/Email)
├── kado24-payout-service/ (Port 8092 - Weekly merchant payouts)
├── kado24-analytics-service/ (Port 8093 - Reports & analytics)
├── kado24-mock-services/ (Port 8095-8099 - Mock external APIs)
├── kado24-api-gateway/ (Apache APISIX configuration)
├── kado24-mobile-consumer/ (Flutter consumer app)
├── kado24-mobile-merchant/ (Flutter merchant app)
├── kado24-admin-portal/ (Angular admin web app)
└── docker/ (Docker Compose configurations)

Requirements:
1. Parent POM with dependency management for all Spring Boot starters
2. Each service module with its own pom.xml
3. Common module with shared entities, DTOs, enums, utilities
4. Maven profiles: dev, test, staging, production
5. Each service with application.yml supporting multiple environments
6. Dockerfile for each service with multi-stage build
7. Docker Compose for local development (PostgreSQL, Redis, Kafka, APISIX)
8. .gitignore configured for Maven, IntelliJ, VS Code
9. README.md with architecture overview and setup instructions
10. Follow naming conventions: kebab-case for folders, PascalCase for Java classes
```

### Prompt 0.2: Docker Infrastructure Setup
```
Create production-ready Docker Compose configuration for Kado24 local development:

File: docker/docker-compose.yml

Required Services:
1. PostgreSQL 17
   - Port: 5432
   - Database: kado24_db
   - User: kado24_user
   - Volume for data persistence
   - Init script: create schemas (auth, core, business, audit)

2. Redis 7
   - Port: 6379
   - Persistence: appendonly
   - Max memory: 512mb
   - Eviction policy: allkeys-lru

3. Apache Kafka 3.x + Zookeeper
   - Kafka Port: 9092
   - Zookeeper Port: 2181
   - Topics: order-events, payment-events, notification-events, redemption-events, analytics-events, audit-events
   - Partitions: 3 for standard topics, 5 for high-volume topics
   - Replication factor: 1 (dev), 3 (prod)

4. etcd 3.5
   - Port: 2379
   - For APISIX service discovery

5. Apache APISIX 3.7
   - Port: 9080 (API Gateway)
   - Port: 9180 (Admin API)
   - Volume: /usr/local/apisix/conf/config.yaml

6. Prometheus
   - Port: 9090
   - Scrape interval: 15s

7. Grafana
   - Port: 3000
   - Default dashboards for microservices

Additional requirements:
- Health checks for all services
- Proper networking with custom bridge network
- Environment variables from .env file
- Logging configuration
- Resource limits (CPU, memory)
```

---

## PHASE 1: Foundation & Infrastructure

### Prompt 1.1: Common Module - DTOs and Entities
```
In kado24-common module, create production-ready shared components:

Package Structure:
com.kado24.common/
├── dto/ (Data Transfer Objects)
│   ├── request/ (API request DTOs with validation)
│   ├── response/ (API response DTOs)
│   └── kafka/ (Kafka event DTOs)
├── entity/ (JPA entities with audit fields)
├── enums/ (All system enumerations)
├── exception/ (Custom exceptions)
├── util/ (Utility classes)
└── constant/ (System constants)

Create the following components:

1. Base Entity (BaseEntity.java):
   - id (UUID primary key)
   - createdAt (LocalDateTime, @CreatedDate)
   - updatedAt (LocalDateTime, @LastModifiedDate)
   - createdBy (String, @CreatedBy)
   - updatedBy (String, @LastModifiedBy)
   - version (Long, @Version for optimistic locking)
   - Use @MappedSuperclass
   - Enable JPA Auditing

2. Common DTOs:
   - ApiResponse<T> (success, message, data, timestamp, errors)
   - PageResponse<T> (content, page, size, totalElements, totalPages)
   - ErrorResponse (code, message, field, timestamp, path)

3. Enums:
   - UserRole (CONSUMER, MERCHANT, ADMIN)
   - UserStatus (PENDING, ACTIVE, SUSPENDED, BANNED)
   - VoucherStatus (DRAFT, PENDING_APPROVAL, ACTIVE, INACTIVE, EXPIRED)
   - OrderStatus (PENDING, PAID, COMPLETED, CANCELLED, REFUNDED)
   - PaymentStatus (INITIATED, PROCESSING, SUCCESS, FAILED, CANCELLED)
   - PaymentMethod (ABA_PAY, WING, PI_PAY, KHQR)
   - RedemptionStatus (VALID, REDEEMED, EXPIRED, CANCELLED)
   - MerchantStatus (PENDING_VERIFICATION, ACTIVE, SUSPENDED, REJECTED)
   - NotificationType (EMAIL, SMS, PUSH)
   - TransactionType (PURCHASE, REDEMPTION, REFUND, GIFT)

4. Custom Exceptions:
   - ResourceNotFoundException
   - DuplicateResourceException
   - InvalidRequestException
   - UnauthorizedException
   - PaymentProcessingException

5. Utility Classes:
   - QRCodeUtil (generate and validate QR codes)
   - ValidationUtil (phone, email, business license validation)
   - DateTimeUtil (Khmer calendar conversions)
   - CurrencyUtil (USD formatting for Cambodia)

All classes must have:
- Comprehensive JavaDoc
- Lombok annotations (@Data, @Builder, @NoArgsConstructor, @AllArgsConstructor)
- Jakarta Validation annotations (@NotNull, @NotBlank, @Email, @Pattern)
- Proper serialization support
```

### Prompt 1.2: Database Schema - PostgreSQL
```
Create production-ready PostgreSQL database schema for Kado24:

Location: docker/postgres/init.sql

Requirements:
1. Create 4 schemas: auth_schema, core_schema, business_schema, audit_schema

2. Auth Schema Tables:
   - oauth2_registered_client (OAuth2 client configurations)
   - oauth2_authorization (Active authorizations)
   - oauth2_authorization_consent (User consent records)
   - oauth2_access_token (Access tokens with TTL)
   - oauth2_refresh_token (Refresh tokens)

3. Core Schema Tables:
   - users (id UUID PK, email, phone, password_hash, role, status, created_at, updated_at)
     * UNIQUE constraint on email and phone
     * GIN index on email for case-insensitive search
     * Partitioning: Range by created_at (yearly)
   
   - user_profiles (user_id FK, full_name, avatar_url, birth_date, gender, address, preferences JSONB)
     * Full-text search on full_name (tsvector)
   
   - merchants (id UUID PK, user_id FK, business_name, business_type, license_number, status, verification_date)
     * Unique index on license_number
     * GIN index on business_name
   
   - merchant_details (merchant_id FK, description, logo_url, banner_url, address, location POINT, bank_info JSONB)
     * GIST index on location for geospatial queries
   
4. Business Schema Tables:
   - vouchers (id UUID PK, merchant_id FK, title, description, category, original_price, selling_price, discount_percent, status, start_date, end_date)
     * B-tree index on (merchant_id, status)
     * GIN index on title for full-text search
   
   - voucher_inventory (voucher_id FK, total_quantity, sold_quantity, reserved_quantity, available_quantity)
     * Check constraint: sold + reserved + available = total
   
   - orders (id UUID PK, order_number, user_id FK, voucher_id FK, quantity, subtotal, commission, total, status, created_at)
     * Partitioning: Range by created_at (monthly)
     * B-tree index on (user_id, created_at DESC)
     * B-tree index on order_number (unique)
   
   - payments (id UUID PK, order_id FK, amount, payment_method, gateway_transaction_id, status, paid_at)
     * B-tree index on gateway_transaction_id
   
   - wallet_vouchers (id UUID PK, order_id FK, user_id FK, voucher_id FK, qr_code, pin_code, redemption_status, activated_at, expires_at)
     * B-tree index on (user_id, redemption_status)
     * Unique index on qr_code
   
   - redemptions (id UUID PK, wallet_voucher_id FK, merchant_id FK, redeemed_by, redeemed_at, verification_method)
     * B-tree index on (merchant_id, redeemed_at DESC)

5. Audit Schema Tables:
   - event_log (id BIGSERIAL PK, event_type, entity_type, entity_id, user_id, changes JSONB, ip_address, user_agent, created_at)
     * Partitioning: Range by created_at (monthly)
     * GIN index on changes
   
   - activity_log (id BIGSERIAL PK, user_id, activity_type, metadata JSONB, created_at)
     * Partitioning: Range by created_at (monthly)

Additional Requirements:
- All timestamps: TIMESTAMP WITH TIME ZONE
- All foreign keys with ON DELETE CASCADE or ON DELETE SET NULL (based on business logic)
- Check constraints for data integrity
- Default values where appropriate
- Comments on tables and important columns
- Indexes for common queries
- Sequences for order numbers, transaction IDs
```

### Prompt 1.3: Apache APISIX Configuration
```
Create production-ready Apache APISIX API Gateway configuration:

File: kado24-api-gateway/apisix/config.yaml

Requirements:
1. Routing Configuration:
   - Route: /oauth2/* → auth-service:8081 (PUBLIC)
   - Route: /api/v1/users/* → user-service:8082 (PROTECTED, OAuth2)
   - Route: /api/v1/vouchers/* → voucher-service:8083 (MIXED: public listing, protected purchase)
   - Route: /api/v1/orders/* → order-service:8084 (PROTECTED)
   - Route: /api/v1/payments/* → payment-service:8085 (PROTECTED)
   - Route: /api/v1/wallet/* → wallet-service:8086 (PROTECTED)
   - Route: /api/v1/redemptions/* → redemption-service:8087 (PROTECTED)
   - Route: /api/v1/merchants/* → merchant-service:8088 (MIXED)
   - Route: /api/admin/* → admin-backend:8089 (PROTECTED, ADMIN role)

2. Plugin Configuration:
   - OAuth2 Introspection Plugin (for protected routes)
   - Rate Limiting Plugin:
     * Public APIs: 100 requests/minute per IP
     * Authenticated APIs: 1000 requests/minute per user
     * Admin APIs: 500 requests/minute per admin
   - CORS Plugin (allow origins from mobile apps and admin portal)
   - Request/Response Transformation
   - Circuit Breaker (failure threshold: 5, timeout: 30s)
   - Prometheus Metrics Plugin
   - Request ID Plugin (trace requests across services)
   - IP Restriction Plugin (admin routes)

3. Service Discovery:
   - Configure etcd for dynamic service registration
   - Health check endpoints for all services
   - Load balancing: Round-robin with health checks

4. Security:
   - SSL/TLS termination
   - API key validation for mobile apps
   - JWT validation for OAuth2 tokens
   - Request/response logging (exclude sensitive fields)

5. Error Handling:
   - Custom error responses
   - 4xx/5xx error mapping
   - Timeout handling

Create also:
- routes.yaml (individual route definitions)
- plugins.yaml (plugin configurations)
- upstreams.yaml (backend service definitions)
```

---

## PHASE 2: Core Backend Services

### Prompt 2.1: Auth Service - OAuth2 Authorization Server
```
Create production-ready OAuth2 Authorization Server (kado24-auth-service, Port 8081):

Technology Stack:
- Spring Boot 3.2
- Spring Security OAuth2 Authorization Server
- Spring Data JPA
- PostgreSQL
- Redis (for token storage)
- BCrypt for password hashing

Required Components:

1. Security Configuration:
   - SecurityConfig.java (OAuth2 Authorization Server configuration)
   - Token TTL: Access token (1 hour), Refresh token (30 days)
   - Token format: JWT with custom claims (userId, role, merchantId if applicable)
   - Grant types: authorization_code, refresh_token, password (for mobile apps)
   - PKCE support for mobile apps

2. Entities:
   - User (id, email, phone, passwordHash, role, status, emailVerified, phoneVerified)
   - OAuthClient (clientId, clientSecret, redirectUris, scopes, grantTypes)

3. API Endpoints:
   POST /oauth2/register
   - Request: { email, phone, password, fullName, role }
   - Validation: email format, phone format (+855...), password strength
   - Response: { userId, message: "Registration successful. Please verify email." }
   - Actions: Create user, send verification email, publish user-registered event
   
   POST /oauth2/login
   - Request: { username (email or phone), password, deviceInfo }
   - Response: { accessToken, refreshToken, expiresIn, user { id, email, role } }
   - Actions: Validate credentials, generate tokens, log login event
   
   POST /oauth2/token (OAuth2 standard endpoint)
   - Support authorization_code, refresh_token, password grant types
   
   POST /oauth2/verify-email
   - Request: { token }
   - Actions: Mark email as verified
   
   POST /oauth2/forgot-password
   - Request: { email }
   - Actions: Generate reset token, send email
   
   POST /oauth2/reset-password
   - Request: { token, newPassword }
   
   POST /oauth2/change-password (Protected)
   - Request: { currentPassword, newPassword }
   
   GET /oauth2/introspect (For APISIX to validate tokens)
   - Request: { token }
   - Response: { active: boolean, userId, role, scope, exp }
   
   POST /oauth2/logout (Protected)
   - Actions: Invalidate tokens

4. Services:
   - UserService (CRUD, password management)
   - OAuthClientService (manage OAuth2 clients)
   - TokenService (generate, validate, revoke tokens)
   - VerificationService (email/phone verification)

5. Security Features:
   - Rate limiting on authentication endpoints
   - Account lockout after 5 failed attempts
   - Password policy enforcement (min 8 chars, uppercase, lowercase, digit, special char)
   - Audit logging for all authentication events
   - Device tracking (log IP, user agent)

6. Exception Handling:
   - InvalidCredentialsException
   - AccountLockedException
   - TokenExpiredException

7. Testing:
   - Unit tests for all services
   - Integration tests for OAuth2 flows
   - Security tests (OWASP)

Follow best practices:
- DTOs for all API requests/responses
- MapStruct for entity-DTO mapping
- Global exception handler
- Comprehensive logging (SLF4J + Logback)
- Swagger/OpenAPI documentation
```

### Prompt 2.2: User Service - Profile Management
```
Create production-ready User Service (kado24-user-service, Port 8082):

Technology Stack:
- Spring Boot 3.2
- Spring Data JPA
- PostgreSQL
- Redis (caching)
- Multipart file upload (avatars)

Required Components:

1. Entities:
   - User (reference from auth-service via user_id)
   - UserProfile (user_id FK, full_name, avatar_url, birth_date, gender, address, city, preferences JSONB)
   - UserPreferences (notifications settings, language, currency)

2. API Endpoints:
   GET /api/v1/users/me (Get current user profile)
   - Response: { userId, email, phone, profile { fullName, avatarUrl, ... }, preferences }
   
   PUT /api/v1/users/me (Update profile)
   - Request: { fullName, birthDate, gender, address, city }
   - Validation: birthDate (age >= 13)
   
   POST /api/v1/users/me/avatar (Upload avatar)
   - Multipart file upload
   - Validation: Image format (JPEG, PNG), max size 5MB
   - Image processing: Resize to 400x400, optimize
   - Storage: /var/kado24/uploads/avatars/
   - Response: { avatarUrl }
   
   PUT /api/v1/users/me/preferences (Update preferences)
   - Request: { notifications { email, push, sms }, language, currency }
   
   GET /api/v1/users/{userId} (Admin only)
   - Get any user profile
   
   GET /api/v1/users (Admin only, paginated)
   - Query params: role, status, search, page, size, sort
   - Search: email, phone, full name
   
   PUT /api/v1/users/{userId}/status (Admin only)
   - Request: { status: ACTIVE | SUSPENDED | BANNED, reason }
   - Actions: Update status, send notification, log event
   
   DELETE /api/v1/users/me (Soft delete)
   - Actions: Mark as deleted, anonymize data, cancel active subscriptions

3. Services:
   - UserProfileService (CRUD operations)
   - AvatarService (upload, resize, storage)
   - UserSearchService (full-text search)

4. Caching Strategy:
   - Cache user profiles in Redis (TTL: 1 hour)
   - Cache invalidation on profile update
   - Cache key: "user:profile:{userId}"

5. Features:
   - Profile completeness indicator (percentage)
   - Activity tracking (last seen, login count)
   - User statistics (orders, vouchers, reviews)

6. Kafka Events:
   - Publish: user-profile-updated, user-avatar-changed
   - Consume: user-registered (create profile), user-deleted (cleanup)

7. File Storage:
   - Local storage with path: /var/kado24/uploads/avatars/{userId}/{filename}
   - Track in database: file_uploads table
   - Scheduled cleanup for orphaned files

8. Testing:
   - Unit tests with Mockito
   - Integration tests with TestContainers (PostgreSQL, Redis)
   - File upload tests

Follow best practices:
- Input validation with Jakarta Validation
- Caching with Spring Cache abstraction
- File upload with size and type validation
- Transactional consistency
- Proper exception handling
```

### Prompt 2.3: Voucher Service - Core Business Logic
```
Create production-ready Voucher Service (kado24-voucher-service, Port 8083):

Technology Stack:
- Spring Boot 3.2
- Spring Data JPA with QueryDSL
- PostgreSQL with full-text search
- Redis (caching)
- Elasticsearch (optional for advanced search)

Required Components:

1. Entities:
   - Voucher (id, merchant_id, title, description, category, original_price, selling_price, discount_percent, images, terms_conditions, status, start_date, end_date, created_at, updated_at)
   - VoucherInventory (voucher_id FK, total_quantity, sold_quantity, reserved_quantity, available_quantity)
   - VoucherCategory (id, name, slug, icon, parent_id)
   - VoucherImage (voucher_id FK, image_url, display_order)
   - VoucherReview (id, voucher_id FK, user_id FK, rating, comment, created_at)

2. API Endpoints (PUBLIC):
   GET /api/v1/vouchers
   - Query params: category, minPrice, maxPrice, search, city, featured, page, size, sort
   - Sort options: latest, popular, price-asc, price-desc, discount
   - Response: PageResponse<VoucherDTO>
   - Caching: Redis cache for 5 minutes
   
   GET /api/v1/vouchers/{id}
   - Response: Full voucher details with merchant info, reviews summary
   - Increment view count
   
   GET /api/v1/vouchers/categories
   - Response: Category tree structure
   - Cached: 1 hour
   
   GET /api/v1/vouchers/featured
   - Return top 10 featured vouchers
   - Cached: 10 minutes
   
   GET /api/v1/vouchers/search
   - Query param: q (search query)
   - Full-text search on title, description
   - Fuzzy matching support

3. API Endpoints (PROTECTED - MERCHANT):
   POST /api/v1/vouchers (Create voucher)
   - Request: { title, description, category, originalPrice, sellingPrice, quantity, images[], termsConditions, startDate, endDate }
   - Validation: selling price < original price, quantity > 0, end date > start date
   - Status: DRAFT → PENDING_APPROVAL (requires admin approval)
   - Actions: Save voucher, upload images, publish voucher-created event
   
   PUT /api/v1/vouchers/{id}
   - Update voucher (only if status is DRAFT or changes require re-approval)
   
   POST /api/v1/vouchers/{id}/publish
   - Submit for admin approval
   - Actions: Change status to PENDING_APPROVAL, notify admins
   
   POST /api/v1/vouchers/{id}/deactivate
   - Deactivate voucher (merchant can deactivate anytime)
   
   GET /api/v1/vouchers/my-vouchers
   - Get merchant's vouchers with status filter
   
   POST /api/v1/vouchers/{id}/images
   - Upload voucher images (max 5 images)
   - Validation: JPEG/PNG, max 2MB each
   - Image processing: Resize to 1200x800, optimize
   
4. API Endpoints (ADMIN):
   PUT /api/v1/vouchers/{id}/approve
   - Request: { approved: boolean, rejectionReason? }
   - Actions: Update status to ACTIVE or REJECTED, notify merchant
   
   PUT /api/v1/vouchers/{id}/feature
   - Mark voucher as featured (appears in home page)

5. Services:
   - VoucherService (CRUD operations)
   - VoucherSearchService (full-text search, filters)
   - VoucherInventoryService (quantity management with locking)
   - VoucherReviewService (ratings & reviews)
   - VoucherImageService (upload, storage, optimization)

6. Inventory Management:
   - Pessimistic locking when reserving vouchers
   - Transaction: Reserve quantity → Process payment → Confirm purchase OR Release reservation
   - Scheduled job: Release expired reservations (after 15 minutes)

7. Search Implementation:
   - PostgreSQL full-text search with tsvector
   - Weighted search: title (A), description (B), category (C)
   - Search index: GIN index on tsvector column
   - Query: to_tsquery with prefix matching

8. Caching Strategy:
   - Voucher details: Cache in Redis (TTL: 30 minutes)
   - Voucher list: Cache first page (TTL: 5 minutes)
   - Categories: Cache full tree (TTL: 1 hour)
   - Cache invalidation: On voucher update, delete specific caches

9. Kafka Events:
   - Publish: voucher-created, voucher-approved, voucher-sold-out, voucher-expiring-soon
   - Consume: order-created (decrease inventory), order-cancelled (increase inventory)

10. Scheduled Jobs:
   - Auto-expire vouchers at end_date (daily at midnight)
   - Send alerts for vouchers expiring in 7 days
   - Update popular voucher rankings (hourly)

11. Database Optimization:
   - Indexes on (category, status), (merchant_id, status), (start_date, end_date)
   - Partial index: WHERE status = 'ACTIVE' AND end_date > NOW()
   - Query optimization with EXPLAIN ANALYZE

12. Testing:
   - Unit tests for business logic
   - Integration tests with TestContainers
   - Performance tests for search queries
   - Concurrency tests for inventory management

Follow best practices:
- Use DTOs with different views (list, detail, merchant)
- Implement soft delete for vouchers
- Audit trail for all changes
- Rate limiting on search endpoints
- Proper exception handling (OutOfStockException, VoucherExpiredException)
```

### Prompt 2.4: Order Service - Order Processing
```
Create production-ready Order Service (kado24-order-service, Port 8084):

Technology Stack:
- Spring Boot 3.2
- Spring Data JPA
- PostgreSQL (table partitioning by month)
- Kafka (event streaming)
- Redis (distributed locking)

Required Components:

1. Entities:
   - Order (id, order_number, user_id, voucher_id, merchant_id, quantity, unit_price, subtotal, commission_amount, commission_percent, merchant_amount, total_amount, status, created_at, updated_at)
   - OrderItem (order_id FK, voucher_id FK, quantity, price)
   - OrderStatusHistory (order_id FK, status, changed_at, changed_by, notes)

2. API Endpoints (PROTECTED):
   POST /api/v1/orders (Create order)
   - Request: { voucherId, quantity, recipientInfo? (for gifting) }
   - Business Logic:
     1. Validate voucher availability (call voucher-service)
     2. Reserve inventory (call voucher-service with distributed lock)
     3. Calculate commission (8% platform, 92% merchant)
     4. Generate order_number (format: ORD-YYYYMMDD-XXXXX)
     5. Create order with status: PENDING
     6. Publish order-created event (Kafka)
     7. Return: { orderId, orderNumber, total, paymentUrl }
   - Validation: quantity > 0, quantity <= available
   - Timeout: Release reservation if payment not completed in 15 minutes
   
   GET /api/v1/orders/{orderId}
   - Response: Full order details with voucher info, payment status
   - Authorization: User can only view own orders
   
   GET /api/v1/orders
   - Query params: status, fromDate, toDate, page, size, sort
   - Response: Paginated list of user's orders
   - Sort options: latest, oldest
   
   PUT /api/v1/orders/{orderId}/cancel
   - Business Logic:
     1. Validate: Can only cancel if status is PENDING or PAID (before redemption)
     2. Initiate refund if already paid
     3. Release inventory
     4. Update status to CANCELLED
     5. Publish order-cancelled event
   - Response: { success, refundId? }

3. API Endpoints (MERCHANT):
   GET /api/v1/orders/merchant/summary
   - Response: { todayOrders, weekOrders, monthOrders, revenue { today, week, month } }
   
   GET /api/v1/orders/merchant/history
   - Query params: status, fromDate, toDate, page, size
   - Response: Orders for merchant's vouchers

4. API Endpoints (ADMIN):
   GET /api/v1/orders/admin/all
   - Query params: status, merchantId, userId, fromDate, toDate, page, size
   - Full order list for platform monitoring
   
   GET /api/v1/orders/admin/analytics
   - Response: GMV, order count, avg order value, by period

5. Services:
   - OrderService (Create, retrieve, cancel orders)
   - OrderCalculationService (Calculate commission, taxes)
   - OrderReservationService (Reserve/release inventory with distributed lock)
   - OrderNumberGenerator (Generate unique order numbers)

6. Commission Calculation:
   - Platform commission: 8% of selling price
   - Merchant amount: 92% of selling price
   - Formula: 
     * subtotal = quantity * selling_price
     * commission_amount = subtotal * 0.08
     * merchant_amount = subtotal * 0.92
     * total_amount = subtotal (customer pays full price)

7. Order State Machine:
   States: PENDING → PAID → COMPLETED | CANCELLED | REFUNDED
   
   Transitions:
   - PENDING → PAID (on payment confirmation)
   - PENDING → CANCELLED (payment timeout or user cancellation)
   - PAID → COMPLETED (after voucher redemption)
   - PAID → REFUNDED (on refund request)
   - PAID → CANCELLED (before redemption, initiates refund)

8. Kafka Event Handling:
   - Publish Events:
     * order-created { orderId, userId, voucherId, merchantId, amount, status }
     * order-paid { orderId, paymentId, amount }
     * order-completed { orderId, completedAt }
     * order-cancelled { orderId, reason }
   
   - Consume Events:
     * payment-completed (update order status to PAID, trigger wallet voucher generation)
     * payment-failed (cancel order, release inventory)
     * redemption-completed (update order status to COMPLETED)

9. Distributed Locking (Redis):
   - Lock key: "order:voucher:reserve:{voucherId}"
   - TTL: 30 seconds
   - Use Redisson for distributed locks
   - Ensure atomic inventory reservation

10. Scheduled Jobs:
    - Expire pending orders after 15 minutes (check every minute)
    - Release reserved inventory for expired orders
    - Send reminder for pending payments (after 10 minutes)

11. Database Partitioning:
    - Partition orders table by month (created_at)
    - Automatic partition creation (12 months ahead)
    - Old partition archiving (after 2 years)

12. Performance Optimization:
    - Index on (user_id, created_at DESC)
    - Index on (merchant_id, status, created_at DESC)
    - Index on order_number (unique)
    - Eager loading for order details to avoid N+1 queries
    - Use database views for merchant summaries

13. Testing:
    - Unit tests for order creation logic
    - Integration tests for order lifecycle
    - Concurrency tests for inventory reservation
    - Performance tests for high-volume orders

Follow best practices:
- Idempotency for order creation (prevent duplicate orders)
- Transaction boundaries (order creation + inventory reservation in single transaction)
- Saga pattern for distributed transactions
- Comprehensive audit logging
- Circuit breaker for external service calls
```

### Prompt 2.5: Payment Service - Gateway Integration
```
Create production-ready Payment Service (kado24-payment-service, Port 8085):

Technology Stack:
- Spring Boot 3.2
- Spring Web (REST clients for payment gateways)
- PostgreSQL
- Kafka (payment events)
- Redis (payment session tracking)

Required Components:

1. Entities:
   - Payment (id, payment_reference, order_id FK, user_id, amount, payment_method, gateway, gateway_transaction_id, status, initiated_at, completed_at, callback_data JSONB)
   - PaymentCallback (id, payment_id FK, callback_type, payload JSONB, processed, received_at)

2. Supported Payment Gateways:
   - ABA PayWay
   - Wing Money
   - Pi Pay
   - KHQR (Bakong QR)

3. API Endpoints (PROTECTED):
   POST /api/v1/payments/initiate
   - Request: { orderId, paymentMethod: ABA_PAY | WING | PI_PAY | KHQR }
   - Business Logic:
     1. Validate order exists and status is PENDING
     2. Create payment record with status: INITIATED
     3. Call payment gateway API to create payment
     4. Store payment session in Redis (TTL: 15 minutes)
     5. Return payment URL for redirect or QR code data
   - Response: { paymentId, paymentUrl?, qrCodeData?, expiresAt }
   
   GET /api/v1/payments/{paymentId}/status
   - Response: { paymentId, status, amount, gateway, transactionId? }
   - Poll endpoint for payment status (for QR code payments)
   
   POST /api/v1/payments/{paymentId}/cancel
   - Cancel pending payment
   - Actions: Update status to CANCELLED, notify payment gateway, release order

4. Callback Endpoints (PUBLIC - for payment gateways):
   POST /api/v1/payments/callback/aba
   - Handle ABA PayWay IPN (Instant Payment Notification)
   - Verify signature
   - Update payment status
   - Publish payment event
   
   POST /api/v1/payments/callback/wing
   - Handle Wing callback
   
   POST /api/v1/payments/callback/pipay
   - Handle Pi Pay webhook
   
   POST /api/v1/payments/callback/khqr
   - Handle KHQR callback

5. Return URLs (for redirect-based gateways):
   GET /api/v1/payments/return/success
   - Payment success return URL
   - Redirect to mobile app with deep link
   
   GET /api/v1/payments/return/cancel
   - Payment cancelled return URL
   
   GET /api/v1/payments/return/error
   - Payment error return URL

6. API Endpoints (ADMIN):
   GET /api/v1/payments/admin/all
   - Query params: status, gateway, fromDate, toDate, page, size
   - Paginated payment list
   
   POST /api/v1/payments/{paymentId}/refund
   - Request: { amount, reason }
   - Initiate refund through payment gateway
   - Update payment status to REFUNDED

7. Payment Gateway Integration:
   
   A) ABA PayWay Integration:
   - Endpoint: https://checkout-sandbox.payway.com.kh/api/payment-gateway/v1/payments/purchase
   - Authentication: API Key + Signature
   - Request: { amount, currency: USD, returnUrl, cancelUrl, items: [...], customer: {...} }
   - Response: { transactionId, paymentUrl }
   - Callback: IPN with signature verification
   
   B) Wing Money Integration:
   - Endpoint: https://api-dev.wing.com.kh/api/v1/payment
   - Authentication: OAuth2 token
   - Request: { merchantId, amount, currency: USD, callbackUrl, customerId }
   - Response: { transactionId, deepLink }
   - Callback: POST with transaction status
   
   C) Pi Pay Integration:
   - Endpoint: https://sandbox-api.pipay.com/v1/checkout
   - Authentication: API Key
   - QR Code based payment
   - Response: { qrCodeData, transactionId }
   - Polling: Check status every 5 seconds
   
   D) KHQR (Bakong) Integration:
   - Generate QR code following Bakong standard
   - Format: khqr://pay?amount=...&merchantId=...
   - Static QR for merchant, dynamic QR per transaction

8. Payment Gateway Abstraction:
   - PaymentGateway Interface:
     * initiatePayment(order, method) -> PaymentResponse
     * verifyCallback(payload, signature) -> boolean
     * getPaymentStatus(transactionId) -> PaymentStatus
     * refundPayment(transactionId, amount) -> RefundResponse
   
   - Implementations:
     * AbaPaywayGateway
     * WingGateway
     * PiPayGateway
     * KhqrGateway

9. Services:
   - PaymentService (orchestrate payment flows)
   - PaymentGatewayFactory (return appropriate gateway based on method)
   - PaymentCallbackService (process gateway callbacks)
   - PaymentRefundService (handle refunds)
   - SignatureVerificationService (verify gateway signatures)

10. Payment State Machine:
    States: INITIATED → PROCESSING → SUCCESS | FAILED | CANCELLED | REFUNDED
    
    Transitions:
    - INITIATED → PROCESSING (user completes payment on gateway)
    - PROCESSING → SUCCESS (gateway confirms payment)
    - PROCESSING → FAILED (gateway declines payment)
    - INITIATED → CANCELLED (user or system cancels)
    - SUCCESS → REFUNDED (admin initiates refund)

11. Kafka Event Publishing:
    - payment-initiated { paymentId, orderId, amount, gateway }
    - payment-processing { paymentId, gatewayTransactionId }
    - payment-completed { paymentId, orderId, amount, gateway, transactionId }
    - payment-failed { paymentId, orderId, reason }
    - payment-cancelled { paymentId, orderId }
    - payment-refunded { paymentId, amount, reason }

12. Security:
    - Signature verification for all callbacks
    - IP whitelist for payment gateway callbacks
    - HTTPS only for all payment endpoints
    - PCI-DSS compliance (never store card details)
    - Rate limiting on initiation endpoints
    - Idempotency keys to prevent duplicate payments

13. Retry Logic:
    - Exponential backoff for gateway API calls
    - Max retries: 3
    - Circuit breaker if gateway is down
    - Fallback to alternative payment methods

14. Monitoring & Alerting:
    - Payment success rate metrics
    - Average payment processing time
    - Failed payment reasons
    - Gateway downtime alerts
    - Abandoned payment tracking

15. Mock Payment Gateway (Development):
    - Mock endpoints for all payment methods
    - Simulate success/failure scenarios
    - Instant callback for testing
    - Toggle via application properties

16. Testing:
    - Unit tests for payment logic
    - Integration tests with mock gateways
    - Contract tests with actual gateway sandboxes
    - Security tests for signature verification
    - Load tests for high-volume scenarios

Follow best practices:
- Never store sensitive payment data
- Use HTTPS everywhere
- Implement idempotency
- Comprehensive logging (mask sensitive fields)
- Webhook replay protection (check timestamp, nonce)
- Transaction atomicity (database + event publishing)
```

### Prompt 2.6: Wallet Service - Digital Voucher Management
```
Create production-ready Wallet Service (kado24-wallet-service, Port 8086):

Technology Stack:
- Spring Boot 3.2
- Spring Data JPA
- PostgreSQL
- Redis (QR code caching)
- ZXing library (QR code generation)

Required Components:

1. Entities:
   - WalletVoucher (id, order_id FK, user_id FK, voucher_id FK, qr_code, pin_code, redemption_status, activated_at, expires_at, redeemed_at, metadata JSONB)
   - GiftTransaction (id, sender_id, recipient_id, wallet_voucher_id FK, message, sent_at, claimed_at)

2. API Endpoints (PROTECTED):
   GET /api/v1/wallet/vouchers
   - Query params: status (ACTIVE, REDEEMED, EXPIRED, GIFTED), page, size
   - Response: Paginated list of wallet vouchers
   - Include: voucher details, expiry info, redemption status
   
   GET /api/v1/wallet/vouchers/{id}
   - Response: Full voucher details with QR code, PIN, merchant info, redemption instructions
   - Generate QR code on-demand if not cached
   
   GET /api/v1/wallet/vouchers/{id}/qr-code
   - Response: QR code image (PNG format)
   - Cache in Redis (key: "qr:voucher:{id}", TTL: 24 hours)
   - QR code content: { voucherId, userId, qrCode, signature }
   
   POST /api/v1/wallet/vouchers/activate
   - Kafka consumer: Triggered by payment-completed event
   - Business Logic:
     1. Create wallet voucher from order
     2. Generate unique QR code (UUID format)
     3. Generate 6-digit PIN code
     4. Set activation and expiry dates
     5. Send push notification to user
   - This is an internal endpoint, not directly exposed to clients
   
   POST /api/v1/wallet/gift
   - Request: { walletVoucherId, recipientEmail or recipientPhone, message }
   - Business Logic:
     1. Validate voucher ownership and status (must be ACTIVE, not redeemed)
     2. Update voucher status to GIFTED
     3. Create gift transaction
     4. Send notification to recipient with claim link
     5. Publish voucher-gifted event
   - Response: { giftId, message: "Gift sent successfully" }
   
   POST /api/v1/wallet/claim-gift
   - Request: { giftToken }
   - Business Logic:
     1. Validate gift token
     2. Transfer wallet voucher to recipient
     3. Update voucher user_id
     4. Mark gift as claimed
     5. Send confirmation to both sender and recipient
   - Response: { walletVoucherId, voucher details }
   
   GET /api/v1/wallet/statistics
   - Response: { totalVouchers, activeVouchers, redeemedVouchers, totalValue, expiringIn7Days }

3. QR Code Generation:
   - Library: ZXing (Zebra Crossing)
   - Format: QR Code 2D barcode
   - Content: JSON { voucherId, userId, qrCode, timestamp, signature }
   - Size: 300x300 pixels
   - Error correction: Level H (30%)
   - Encoding: UTF-8
   - Signature: HMAC-SHA256 for security

4. PIN Code:
   - 6-digit numeric code
   - Unique per voucher
   - Stored hashed (BCrypt)
   - Used for manual verification if QR fails

5. Voucher Lifecycle:
   States: PENDING → ACTIVE → REDEEMED | EXPIRED | GIFTED → CLAIMED
   
   - PENDING: Order paid, voucher creation in progress
   - ACTIVE: Ready to use, not redeemed, not expired
   - REDEEMED: Successfully used at merchant
   - EXPIRED: Past expiry date, cannot be used
   - GIFTED: Transferred to another user, pending claim
   - CLAIMED: Gifted voucher accepted by recipient

6. Expiry Management:
   - Default expiry: 90 days from activation
   - Custom expiry based on voucher configuration
   - Warning: Notify user 7 days before expiry
   - Scheduled job: Mark expired vouchers (daily at midnight)

7. Services:
   - WalletVoucherService (CRUD, lifecycle management)
   - QRCodeService (generate, validate QR codes)
   - PinCodeService (generate, validate PINs)
   - GiftService (send, claim gifts)
   - VoucherExpiryService (check and notify expiring vouchers)

8. Kafka Event Handling:
   - Consume:
     * payment-completed (activate voucher)
     * order-cancelled (prevent activation or delete wallet voucher)
   
   - Publish:
     * voucher-activated { walletVoucherId, userId, voucherId, expiresAt }
     * voucher-gifted { giftId, senderId, recipientIdentifier, walletVoucherId }
     * voucher-claimed { giftId, recipientId, walletVoucherId }
     * voucher-expiring-soon { walletVoucherId, userId, expiresAt, daysLeft }
     * voucher-expired { walletVoucherId, userId, expiredAt }

9. Security:
   - QR code signature to prevent tampering
   - Signature algorithm: HMAC-SHA256 with secret key
   - Signature included in QR data, verified on redemption
   - PIN code hashed with BCrypt
   - Rate limiting on gift claiming (prevent abuse)

10. Caching Strategy:
    - Cache QR code images in Redis
    - Cache key: "qr:voucher:{walletVoucherId}"
    - TTL: 24 hours
    - Cache active voucher list per user (TTL: 5 minutes)

11. Scheduled Jobs:
    - Mark expired vouchers: Daily at 00:00
    - Send expiry warnings: Daily at 08:00 (7 days, 3 days, 1 day before)
    - Clean up old QR code cache: Weekly

12. Gifting Flow:
    1. User selects voucher to gift
    2. Enters recipient email/phone and optional message
    3. System creates gift transaction with unique token
    4. Sends notification to recipient with claim link
    5. Recipient clicks link, opens app/web
    6. System verifies token, transfers voucher ownership
    7. Both parties receive confirmation

13. Database Optimization:
    - Index on (user_id, redemption_status)
    - Index on (qr_code) - unique
    - Index on (expires_at, redemption_status) for expiry checks
    - Partial index: WHERE redemption_status = 'ACTIVE' (for active vouchers query)

14. Testing:
    - Unit tests for QR code generation and validation
    - Unit tests for PIN code generation and hashing
    - Integration tests for voucher activation flow
    - Integration tests for gifting flow
    - Performance tests for QR code generation at scale

Follow best practices:
- QR code signature verification on every redemption attempt
- Secure PIN storage (never plain text)
- Transaction management for gift transfers
- Comprehensive logging (who, what, when)
- Error handling for edge cases (duplicate activation, expired vouchers)
```

### Prompt 2.7: Redemption Service - QR Scanning & Validation
```
Create production-ready Redemption Service (kado24-redemption-service, Port 8087):

Technology Stack:
- Spring Boot 3.2
- Spring Data JPA
- PostgreSQL
- Redis (rate limiting, caching)
- Kafka (redemption events)

Required Components:

1. Entities:
   - Redemption (id, wallet_voucher_id FK, merchant_id FK, redeemed_by (merchant user), redeemed_at, verification_method (QR_SCAN, PIN_ENTRY, MANUAL), notes, location POINT, device_info JSONB)
   - RedemptionAttempt (id, wallet_voucher_id FK, merchant_id FK, attempted_by, attempted_at, result (SUCCESS, FAILED), failure_reason)

2. API Endpoints (MERCHANT APP):
   POST /api/v1/redemptions/validate
   - Request: { qrCode?, pinCode?, walletVoucherId }
   - Business Logic:
     1. Verify merchant is authenticated
     2. Validate QR code signature OR PIN code
     3. Check voucher status (must be ACTIVE)
     4. Check voucher not expired
     5. Check voucher belongs to this merchant's vouchers
     6. Return validation result with voucher details
   - Response: { valid: boolean, voucher { title, value, customerName, expiresAt }, reason? }
   - Rate Limit: 60 requests/minute per merchant
   - Log all attempts (success/failure) for audit
   
   POST /api/v1/redemptions/redeem
   - Request: { qrCode?, pinCode?, walletVoucherId, notes? }
   - Business Logic:
     1. Validate voucher (same as /validate)
     2. Check if already redeemed (prevent double redemption)
     3. Create redemption record
     4. Update wallet voucher status to REDEEMED
     5. Record merchant, timestamp, location
     6. Publish redemption-completed event
     7. Send confirmation to customer
   - Response: { redemptionId, message: "Voucher redeemed successfully", customerName, voucherDetails }
   - This is atomic: Either full success or full rollback
   - Distributed lock: "redemption:voucher:{walletVoucherId}" to prevent concurrent redemptions
   
   GET /api/v1/redemptions/history
   - Query params: fromDate, toDate, page, size
   - Response: Paginated redemption history for logged-in merchant
   - Include: customer name, voucher title, redeemed_at, value

3. API Endpoints (CONSUMER APP - for verification):
   GET /api/v1/redemptions/my-redemptions
   - Query params: fromDate, toDate, page, size
   - Response: User's redemption history
   - Include: merchant name, voucher title, redeemed_at, location

4. API Endpoints (ADMIN):
   GET /api/v1/redemptions/admin/all
   - Query params: merchantId, userId, fromDate, toDate, page, size
   - Response: All redemptions with filtering
   
   POST /api/v1/redemptions/{id}/reverse
   - Request: { reason }
   - Business Logic: Mark redemption as reversed, reactivate voucher
   - Use case: Customer dispute, merchant error

5. Validation Logic:
   
   QR Code Validation:
   - Parse QR code JSON: { voucherId, userId, qrCode, timestamp, signature }
   - Verify signature: HMAC-SHA256(voucherId + userId + qrCode + timestamp, SECRET_KEY)
   - Check timestamp: Not older than 30 days (prevent replay attacks)
   - Look up wallet voucher by qrCode
   - Verify voucher belongs to merchant's brand/outlets
   
   PIN Code Validation:
   - Look up wallet voucher by PIN (hashed)
   - BCrypt.checkpw(inputPin, storedHashedPin)
   - Additional check: Voucher ID + PIN combination
   
   Business Rules:
   - Voucher must be ACTIVE status
   - Voucher must not be expired (expires_at > NOW())
   - Voucher must belong to merchant's vouchers
   - Voucher can only be redeemed once
   - Merchant must be ACTIVE status
   - Geographic validation: Optional check if redemption location matches merchant location (tolerance: 1km)

6. Services:
   - RedemptionService (redeem, validate, history)
   - QRValidationService (verify QR signature and content)
   - PinValidationService (verify PIN)
   - MerchantValidationService (verify merchant can redeem voucher)
   - VoucherValidationService (check status, expiry, merchant match)

7. Security Features:
   - Distributed locking with Redis (Redisson)
   - Lock key: "redemption:voucher:{walletVoucherId}"
   - Lock TTL: 10 seconds
   - Rate limiting per merchant: 60 redemptions/minute (prevent abuse)
   - Signature verification on every QR scan
   - Log all redemption attempts (for fraud detection)

8. Fraud Detection:
   - Multiple failed attempts from same merchant → Alert
   - Same voucher scanned multiple times in short period → Alert
   - Unusual redemption patterns (time, location) → Flag for review
   - Store redemption location (lat/long) for verification

9. Kafka Event Publishing:
   - redemption-attempted { attemptId, walletVoucherId, merchantId, result, timestamp }
   - redemption-completed { redemptionId, walletVoucherId, orderId, merchantId, userId, timestamp, location }
   - redemption-failed { attemptId, walletVoucherId, merchantId, reason, timestamp }
   - suspicious-redemption-detected { walletVoucherId, merchantId, reason, flaggedAt }

10. Offline Mode Support (for Merchant App):
    - Merchant app can cache voucher validation rules
    - Store redemptions locally when offline
    - Sync to server when connection restored
    - Flag offline redemptions for verification
    - Redemption conflict resolution: Server timestamp wins

11. Database Optimization:
    - Index on (merchant_id, redeemed_at DESC)
    - Index on (wallet_voucher_id) - unique for preventing double redemption
    - Index on (redeemed_at) for time-based queries
    - Partial index on attempted redemptions: WHERE result = 'FAILED'

12. Analytics & Reporting:
    - Redemption rate by voucher
    - Peak redemption times
    - Average time from purchase to redemption
    - Merchant redemption velocity
    - Failed redemption reasons (for UX improvement)

13. Testing:
    - Unit tests for QR signature verification
    - Unit tests for PIN validation
    - Integration tests for redemption flow
    - Concurrency tests (prevent double redemption)
    - Security tests (invalid QR, expired voucher, wrong merchant)
    - Performance tests (high-volume redemptions)

Follow best practices:
- Atomic redemption: All or nothing (use @Transactional)
- Idempotency: Same redemption request returns same result
- Comprehensive logging: Log every validation attempt with result
- Audit trail: Who redeemed, when, where, how
- Security first: Always verify signatures, check permissions
- Error messages: Clear but don't leak security info
```

---

## PHASE 3: Mobile Applications

### Prompt 3.1: Flutter Project Setup - Consumer App
```
Create production-ready Flutter Consumer App (kado24-mobile-consumer):

Project Structure:
lib/
├── main.dart
├── app.dart (MaterialApp configuration)
├── config/
│   ├── api_config.dart (Base URLs, endpoints)
│   ├── app_config.dart (App constants, feature flags)
│   └── theme/
│       ├── app_theme.dart (Light/dark themes)
│       ├── app_colors.dart
│       └── app_text_styles.dart
├── core/
│   ├── di/ (Dependency injection - GetIt)
│   ├── network/
│   │   ├── api_client.dart (Dio client with interceptors)
│   │   ├── api_interceptors.dart (Auth, logging, error handling)
│   │   └── api_endpoints.dart
│   ├── storage/
│   │   ├── local_storage.dart (SharedPreferences wrapper)
│   │   └── secure_storage.dart (FlutterSecureStorage for tokens)
│   ├── error/
│   │   ├── exceptions.dart
│   │   └── failures.dart
│   └── utils/
│       ├── validators.dart
│       ├── formatters.dart (currency, date)
│       └── logger.dart
├── features/
│   ├── auth/
│   │   ├── data/ (API, models, repository impl)
│   │   ├── domain/ (entities, repository interface, use cases)
│   │   └── presentation/ (screens, widgets, bloc)
│   ├── home/
│   ├── vouchers/
│   ├── orders/
│   ├── wallet/
│   ├── profile/
│   └── ...
├── shared/
│   ├── widgets/ (Reusable UI components)
│   ├── models/ (Shared data models)
│   └── extensions/ (Dart extensions)
└── l10n/ (Internationalization - English, Khmer)

Dependencies (pubspec.yaml):
```yaml
dependencies:
  flutter:
    sdk: flutter
  
  # State Management
  flutter_bloc: ^8.1.3
  equatable: ^2.0.5
  
  # Networking
  dio: ^5.3.3
  retrofit: ^4.0.3
  pretty_dio_logger: ^1.3.1
  
  # Storage
  shared_preferences: ^2.2.2
  flutter_secure_storage: ^9.0.0
  hive: ^2.2.3
  hive_flutter: ^1.1.0
  
  # Dependency Injection
  get_it: ^7.6.4
  injectable: ^2.3.2
  
  # UI/UX
  cached_network_image: ^3.3.0
  flutter_svg: ^2.0.9
  shimmer: ^3.0.0
  lottie: ^2.7.0
  flutter_slidable: ^3.0.0
  
  # QR Code
  qr_flutter: ^4.1.0
  mobile_scanner: ^3.5.2
  
  # Payments
  webview_flutter: ^4.4.2
  
  # Push Notifications
  firebase_messaging: ^14.7.6
  firebase_core: ^2.24.2
  flutter_local_notifications: ^16.2.0
  
  # Analytics
  firebase_analytics: ^10.7.4
  
  # Utils
  intl: ^0.18.1
  url_launcher: ^6.2.1
  image_picker: ^1.0.5
  permission_handler: ^11.0.1
  connectivity_plus: ^5.0.2
  
  # Form Validation
  reactive_forms: ^16.1.1
  
dev_dependencies:
  flutter_test:
    sdk: flutter
  build_runner: ^2.4.6
  retrofit_generator: ^8.0.4
  hive_generator: ^2.0.1
  injectable_generator: ^2.4.1
  mockito: ^5.4.3
  bloc_test: ^9.1.5
  flutter_launcher_icons: ^0.13.1
  flutter_native_splash: ^2.3.5
```

Features to Implement (30+ screens):
1. Onboarding & Authentication (5 screens)
2. Home & Discovery (3 screens)
3. Voucher Browsing & Details (4 screens)
4. Cart & Checkout (3 screens)
5. Payment Integration (2 screens)
6. Wallet & QR Codes (4 screens)
7. Order History (2 screens)
8. Profile & Settings (5 screens)
9. Reviews & Ratings (2 screens)

Best Practices:
- Clean Architecture (data, domain, presentation layers)
- BLoC pattern for state management
- Repository pattern for data access
- Dependency injection with GetIt
- Error handling with Either<Failure, Success> (dartz package)
- Proper null safety
- Responsive UI (support tablets)
- Offline-first where applicable
- Unit tests for business logic
- Widget tests for UI
- Integration tests for critical flows
```

### Prompt 3.2: Authentication Feature - Consumer App
```
Implement complete Authentication feature for Consumer App:

Screens to build:
1. Splash Screen
2. Onboarding (3 pages with PageView)
3. Login Screen
4. Sign Up Screen
5. Phone Verification (OTP)
6. Forgot Password
7. Reset Password

File Structure:
features/auth/
├── data/
│   ├── datasources/
│   │   ├── auth_remote_datasource.dart (API calls)
│   │   └── auth_local_datasource.dart (Token storage)
│   ├── models/
│   │   ├── user_model.dart
│   │   ├── auth_response_model.dart
│   │   └── login_request_model.dart
│   └── repositories/
│       └── auth_repository_impl.dart
├── domain/
│   ├── entities/
│   │   ├── user.dart
│   │   └── auth_tokens.dart
│   ├── repositories/
│   │   └── auth_repository.dart
│   └── usecases/
│       ├── login_usecase.dart
│       ├── register_usecase.dart
│       ├── verify_otp_usecase.dart
│       ├── logout_usecase.dart
│       └── refresh_token_usecase.dart
└── presentation/
    ├── bloc/
    │   ├── auth_bloc.dart
    │   ├── auth_event.dart
    │   └── auth_state.dart
    ├── screens/
    │   ├── splash_screen.dart
    │   ├── onboarding_screen.dart
    │   ├── login_screen.dart
    │   ├── signup_screen.dart
    │   ├── otp_verification_screen.dart
    │   └── forgot_password_screen.dart
    └── widgets/
        ├── auth_button.dart
        ├── auth_text_field.dart
        ├── social_login_buttons.dart
        └── password_strength_indicator.dart

Implementation Details:

1. Login Screen:
   - Email/Phone input field
   - Password input field (with show/hide toggle)
   - "Remember me" checkbox
   - "Forgot password?" link
   - Login button with loading state
   - "Or continue with" divider
   - Social login buttons (Facebook, Google, Apple)
   - "Don't have account? Sign up" link
   - Form validation (email format, password min 8 chars)
   - Show error messages below fields
   - Disable button while loading

2. Sign Up Screen:
   - Full name input
   - Email input
   - Phone input (+855 prefix)
   - Password input with strength indicator
   - Confirm password input
   - Terms & conditions checkbox
   - Sign up button
   - Navigate to OTP verification on success

3. OTP Verification:
   - 6-digit code input (auto-focus, auto-advance)
   - Timer countdown (60 seconds)
   - Resend OTP button (enabled after timeout)
   - Verify button
   - "Didn't receive code?" text
   - Auto-submit when 6 digits entered

4. API Integration:
   ```dart
   // auth_remote_datasource.dart
   abstract class AuthRemoteDataSource {
     Future<AuthResponse> login(LoginRequest request);
     Future<AuthResponse> register(RegisterRequest request);
     Future<void> verifyOtp(String phone, String code);
     Future<void> forgotPassword(String email);
     Future<void> resetPassword(String token, String newPassword);
     Future<AuthResponse> refreshToken(String refreshToken);
     Future<void> logout();
   }
   
   class AuthRemoteDataSourceImpl implements AuthRemoteDataSource {
     final Dio dio;
     
     @override
     Future<AuthResponse> login(LoginRequest request) async {
       try {
         final response = await dio.post('/oauth2/login', data: request.toJson());
         return AuthResponse.fromJson(response.data);
       } on DioException catch (e) {
         throw ServerException(e.response?.data['message'] ?? 'Login failed');
       }
     }
     // ... implement other methods
   }
   ```

5. Token Management:
   - Store access token in secure storage
   - Store refresh token in secure storage
   - Automatic token refresh before expiry
   - Dio interceptor to add Authorization header
   - Handle 401 responses (invalid token)
   - Redirect to login if refresh fails

6. BLoC Implementation:
   ```dart
   // auth_bloc.dart
   class AuthBloc extends Bloc<AuthEvent, AuthState> {
     final LoginUseCase loginUseCase;
     final RegisterUseCase registerUseCase;
     final LogoutUseCase logoutUseCase;
     
     AuthBloc({...}) : super(AuthInitial()) {
       on<LoginRequested>(_onLoginRequested);
       on<RegisterRequested>(_onRegisterRequested);
       on<LogoutRequested>(_onLogoutRequested);
       on<CheckAuthStatus>(_onCheckAuthStatus);
     }
     
     Future<void> _onLoginRequested(LoginRequested event, Emitter<AuthState> emit) async {
       emit(AuthLoading());
       final result = await loginUseCase(LoginParams(email: event.email, password: event.password));
       result.fold(
         (failure) => emit(AuthError(failure.message)),
         (user) => emit(AuthAuthenticated(user)),
       );
     }
   }
   ```

7. Form Validation:
   - Email: Use regex for valid email format
   - Phone: Validate Cambodia format (+855 followed by 8-9 digits)
   - Password: Min 8 chars, uppercase, lowercase, digit, special char
   - Real-time validation (show errors on blur or change)

8. Social Login Integration:
   - Facebook Login: use facebook_auth package
   - Google Sign-In: use google_sign_in package
   - Apple Sign In: use sign_in_with_apple package (iOS only)
   - Send social token to backend for validation
   - Backend creates/links user account

9. Secure Storage:
   ```dart
   class TokenStorage {
     final FlutterSecureStorage _secureStorage;
     
     Future<void> saveTokens(String accessToken, String refreshToken) async {
       await _secureStorage.write(key: 'access_token', value: accessToken);
       await _secureStorage.write(key: 'refresh_token', value: refreshToken);
     }
     
     Future<String?> getAccessToken() => _secureStorage.read(key: 'access_token');
     Future<String?> getRefreshToken() => _secureStorage.read(key: 'refresh_token');
     
     Future<void> deleteTokens() async {
       await _secureStorage.delete(key: 'access_token');
       await _secureStorage.delete(key: 'refresh_token');
     }
   }
   ```

10. Navigation:
    - Use go_router or auto_route for navigation
    - Protected routes (require authentication)
    - Auto-redirect to login if not authenticated
    - Deep linking support

Testing:
- Unit tests for BLoC events/states
- Unit tests for use cases
- Widget tests for each screen
- Integration test for full auth flow
- Mock API responses for testing
```

### Prompt 3.3: Home & Voucher Discovery - Consumer App
```
Implement Home Screen and Voucher Discovery features:

Screens:
1. Home Screen (Main dashboard)
2. Voucher List Screen (with filters)
3. Voucher Detail Screen
4. Search Screen

File Structure:
features/home/
├── data/...
├── domain/...
└── presentation/
    ├── bloc/
    │   ├── home_bloc.dart
    │   ├── featured_vouchers_bloc.dart
    │   └── categories_bloc.dart
    ├── screens/
    │   └── home_screen.dart
    └── widgets/
        ├── app_bar_with_search.dart
        ├── banner_carousel.dart
        ├── category_list.dart
        ├── featured_voucher_card.dart
        ├── voucher_card_horizontal.dart
        └── section_header.dart

features/vouchers/
├── data/...
├── domain/...
└── presentation/
    ├── bloc/
    │   ├── voucher_list_bloc.dart
    │   ├── voucher_detail_bloc.dart
    │   └── voucher_filter_bloc.dart
    ├── screens/
    │   ├── voucher_list_screen.dart
    │   ├── voucher_detail_screen.dart
    │   └── search_screen.dart
    └── widgets/
        ├── voucher_card.dart
        ├── filter_chip_list.dart
        ├── price_range_slider.dart
        ├── sort_bottom_sheet.dart
        ├── filter_bottom_sheet.dart
        ├── voucher_image_carousel.dart
        ├── merchant_info_card.dart
        └── review_list.dart

Home Screen UI Components:

1. App Bar:
   - Search bar (tap to open search screen)
   - Notification icon with badge (unread count)
   - Cart icon with badge (item count)

2. Banner Carousel:
   - Auto-sliding promotional banners (PageView)
   - Dot indicators
   - Deep links to specific vouchers/categories

3. Categories Section:
   - Horizontal scrollable list
   - Icon + label for each category
   - Tap to filter vouchers by category

4. Featured Vouchers:
   - Grid or horizontal scrollable list
   - Show: Image, title, discount %, original/sale price
   - "Featured" badge overlay

5. "New Arrivals" Section:
   - Latest vouchers (sort by created_at)

6. "Popular" Section:
   - Most purchased vouchers

7. "Near You" Section (if location permission):
   - Vouchers from nearby merchants
   - Distance display

8. "Expiring Soon" Section:
   - Vouchers ending in < 7 days
   - Countdown timer

Implementation:

```dart
// home_screen.dart
class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: RefreshIndicator(
        onRefresh: () => context.read<HomeBloc>().add(HomeRefreshed()),
        child: CustomScrollView(
          slivers: [
            SliverAppBar(
              floating: true,
              title: SearchBarWidget(onTap: () => Navigator.push(...SearchScreen)),
              actions: [NotificationIcon(), CartIcon()],
            ),
            SliverToBoxAdapter(child: BannerCarousel()),
            SliverToBoxAdapter(child: CategoryList()),
            SliverToBoxAdapter(child: SectionHeader(title: 'Featured Vouchers')),
            SliverGrid(
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                childAspectRatio: 0.75,
              ),
              delegate: SliverChildBuilderDelegate(
                (context, index) => VoucherCard(voucher: vouchers[index]),
                childCount: vouchers.length,
              ),
            ),
            // ... more sections
          ],
        ),
      ),
      bottomNavigationBar: CustomBottomNavBar(currentIndex: 0),
    );
  }
}
```

Voucher List Screen:

1. App Bar:
   - Back button
   - Title (category name or "All Vouchers")
   - Filter icon (open filter bottom sheet)
   - Sort icon (open sort bottom sheet)

2. Filter Chips (below app bar):
   - Active filters display as chips (removable)
   - "Clear all" button if filters applied

3. Voucher Grid/List:
   - Toggle between grid and list view
   - Infinite scroll with pagination
   - Pull to refresh
   - Empty state if no results
   - Loading shimmer effect

4. Filter Bottom Sheet:
   - Category multi-select
   - Price range slider
   - Discount range slider
   - Merchant rating filter
   - Location/distance filter
   - "Apply" and "Reset" buttons

5. Sort Bottom Sheet:
   - Latest, Popular, Price: Low to High, Price: High to Low, Discount: High to Low
   - Radio button selection

Voucher Detail Screen:

1. Image Carousel:
   - Multiple images (swipeable)
   - Page indicators
   - Zoom on tap
   - Share and favorite buttons overlay

2. Voucher Info Card:
   - Title (bold, large)
   - Merchant name (with logo, tap to view merchant)
   - Original price (strikethrough)
   - Sale price (large, colored)
   - Discount percentage badge
   - Rating stars + review count

3. Quantity Selector:
   - "-" button, quantity display, "+" button
   - Max quantity limit

4. CTA Buttons:
   - "Buy Now" (primary button)
   - "Add to Cart" (secondary button)

5. Tabs:
   - Details: Full description, terms & conditions
   - How to Use: Redemption instructions
   - Location: Merchant addresses (with map)
   - Reviews: Customer reviews (with photos)

6. Merchant Info Section:
   - Merchant card (logo, name, rating)
   - "View More Vouchers" button

7. Similar Vouchers Section:
   - Horizontal scrollable list
   - From same category or merchant

Implementation:

```dart
// voucher_detail_screen.dart
class VoucherDetailScreen extends StatefulWidget {
  final String voucherId;
  
  @override
  _VoucherDetailScreenState createState() => _VoucherDetailScreenState();
}

class _VoucherDetailScreenState extends State<VoucherDetailScreen> {
  int quantity = 1;
  
  @override
  Widget build(BuildContext context) {
    return BlocBuilder<VoucherDetailBloc, VoucherDetailState>(
      builder: (context, state) {
        if (state is VoucherDetailLoading) return LoadingWidget();
        if (state is VoucherDetailError) return ErrorWidget(state.message);
        if (state is VoucherDetailLoaded) {
          return Scaffold(
            body: CustomScrollView(
              slivers: [
                SliverAppBar(
                  expandedHeight: 300,
                  flexibleSpace: VoucherImageCarousel(images: state.voucher.images),
                  actions: [ShareButton(), FavoriteButton()],
                ),
                SliverToBoxAdapter(
                  child: Column(
                    children: [
                      VoucherInfoCard(voucher: state.voucher),
                      QuantitySelector(
                        quantity: quantity,
                        onChanged: (val) => setState(() => quantity = val),
                        max: state.voucher.availableQuantity,
                      ),
                      TabBar(tabs: [Details, How to Use, Location, Reviews]),
                      TabBarView(children: [...]),
                      MerchantInfoCard(merchant: state.merchant),
                      SimilarVouchersSection(vouchers: state.similarVouchers),
                    ],
                  ),
                ),
              ],
            ),
            bottomNavigationBar: BottomAppBar(
              child: Row(
                children: [
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () => _buyNow(context),
                      child: Text('Buy Now - ${state.voucher.totalPrice(quantity)}'),
                    ),
                  ),
                  IconButton(
                    icon: Icon(Icons.shopping_cart),
                    onPressed: () => _addToCart(context),
                  ),
                ],
              ),
            ),
          );
        }
        return SizedBox();
      },
    );
  }
  
  void _buyNow(BuildContext context) {
    // Navigate to checkout with this voucher
    Navigator.push(context, MaterialPageRoute(
      builder: (_) => CheckoutScreen(
        items: [CartItem(voucher: voucher, quantity: quantity)],
      ),
    ));
  }
  
  void _addToCart(BuildContext context) {
    context.read<CartBloc>().add(AddToCart(voucher, quantity));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Added to cart')),
    );
  }
}
```

Search Screen:

1. Search Bar:
   - Auto-focus on screen open
   - Clear button
   - Voice search button
   - Show recent searches

2. Suggestions:
   - Show popular searches if input empty
   - Show auto-complete suggestions while typing
   - Tap to search

3. Results:
   - Display as voucher grid
   - Highlight search terms in results
   - Filter and sort options

4. Recent Searches:
   - Store last 10 searches locally
   - Clear history button

API Integration:

```dart
// voucher_repository.dart
abstract class VoucherRepository {
  Future<List<Voucher>> getFeaturedVouchers();
  Future<List<Voucher>> getVouchers({
    String? category,
    double? minPrice,
    double? maxPrice,
    String? search,
    String? sort,
    int page = 1,
    int size = 20,
  });
  Future<Voucher> getVoucherDetail(String id);
  Future<List<Category>> getCategories();
  Future<List<Voucher>> searchVouchers(String query);
}
```

Caching Strategy:
- Cache featured vouchers for 10 minutes
- Cache categories for 1 hour
- Cache voucher details for 30 minutes
- Use Hive for offline storage

Performance Optimization:
- Lazy load images with CachedNetworkImage
- Implement pagination (load more on scroll)
- Debounce search input (500ms delay)
- Use const constructors where possible
- Optimize list rendering with ListView.builder

Testing:
- Unit tests for BLoC logic
- Widget tests for all screens
- Golden tests for UI consistency
- Integration tests for search and filter flows
```

---

(PART 1 of 2 - Due to length, I'll continue with the remaining sections in the next file)
# Kado24 Cambodia - Cursor AI Development Guide (Part 2)

## PHASE 3: Mobile Applications (Continued)

### Prompt 3.4: Checkout & Payment Flow - Consumer App
```
Implement complete Checkout and Payment features:

Screens:
1. Cart Screen
2. Checkout Screen  
3. Payment Method Selection
4. Payment WebView Screen
5. Order Confirmation Screen

File Structure:
features/cart/
├── data/...
├── domain/...
└── presentation/
    ├── bloc/cart_bloc.dart
    ├── screens/cart_screen.dart
    └── widgets/
        ├── cart_item_card.dart
        └── cart_summary.dart

features/checkout/
├── data/...
├── domain/...
└── presentation/
    ├── bloc/
    │   ├── checkout_bloc.dart
    │   └── payment_bloc.dart
    ├── screens/
    │   ├── checkout_screen.dart
    │   ├── payment_method_screen.dart
    │   ├── payment_webview_screen.dart
    │   └── order_confirmation_screen.dart
    └── widgets/
        ├── order_summary_card.dart
        ├── payment_method_tile.dart
        └── processing_indicator.dart

Cart Screen Implementation:

1. UI Components:
   - App bar with title "My Cart"
   - List of cart items (swipe to delete)
   - Each item shows: image, title, quantity selector, price
   - Empty cart state (illustration + message)
   - Subtotal display
   - "Proceed to Checkout" button (sticky bottom)

2. Cart Operations:
   - Add/remove items
   - Update quantity
   - Clear cart
   - Persist cart locally (Hive)

```dart
// cart_screen.dart
class CartScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return BlocBuilder<CartBloc, CartState>(
      builder: (context, state) {
        if (state is CartLoaded) {
          return Scaffold(
            appBar: AppBar(
              title: Text('My Cart (${state.items.length})'),
              actions: [
                if (state.items.isNotEmpty)
                  TextButton(
                    child: Text('Clear'),
                    onPressed: () => context.read<CartBloc>().add(ClearCart()),
                  ),
              ],
            ),
            body: state.items.isEmpty
                ? EmptyCartWidget()
                : Column(
                    children: [
                      Expanded(
                        child: ListView.builder(
                          itemCount: state.items.length,
                          itemBuilder: (context, index) {
                            return Slidable(
                              endActionPane: ActionPane(
                                motion: ScrollMotion(),
                                children: [
                                  SlidableAction(
                                    onPressed: (_) => context.read<CartBloc>()
                                        .add(RemoveFromCart(state.items[index])),
                                    backgroundColor: Colors.red,
                                    icon: Icons.delete,
                                    label: 'Remove',
                                  ),
                                ],
                              ),
                              child: CartItemCard(
                                item: state.items[index],
                                onQuantityChanged: (quantity) {
                                  context.read<CartBloc>().add(
                                    UpdateCartItem(state.items[index], quantity),
                                  );
                                },
                              ),
                            );
                          },
                        ),
                      ),
                      CartSummary(subtotal: state.subtotal),
                    ],
                  ),
            bottomNavigationBar: state.items.isNotEmpty
                ? Padding(
                    padding: EdgeInsets.all(16),
                    child: ElevatedButton(
                      onPressed: () => Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => CheckoutScreen()),
                      ),
                      child: Text('Proceed to Checkout - \$${state.subtotal}'),
                    ),
                  )
                : null,
          );
        }
        return LoadingWidget();
      },
    );
  }
}
```

Checkout Screen:

1. Order Review Section:
   - List of items being purchased
   - Each shows: thumbnail, title, quantity, price
   - Non-editable (link back to cart to make changes)

2. Recipient Information (for gifting):
   - Toggle: "Buy for myself" / "Send as gift"
   - If gift: Recipient name, phone, message fields

3. Order Summary:
   - Subtotal
   - Platform fee (8% commission - shown to user as service fee)
   - Total
   - Breakdown: "You save $XX with this discount"

4. Terms & Conditions:
   - Checkbox with link to T&C
   - Must be checked to proceed

5. CTA Button:
   - "Proceed to Payment" button
   - Validates all fields
   - Shows loading state while creating order

```dart
// checkout_screen.dart
class CheckoutScreen extends StatefulWidget {
  @override
  _CheckoutScreenState createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  bool isGift = false;
  bool termsAccepted = false;
  final _formKey = GlobalKey<FormState>();
  
  @override
  Widget build(BuildContext context) {
    return BlocConsumer<CheckoutBloc, CheckoutState>(
      listener: (context, state) {
        if (state is OrderCreated) {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => PaymentMethodScreen(orderId: state.orderId),
            ),
          );
        } else if (state is CheckoutError) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(state.message)),
          );
        }
      },
      builder: (context, state) {
        return Scaffold(
          appBar: AppBar(title: Text('Checkout')),
          body: SingleChildScrollView(
            padding: EdgeInsets.all(16),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Order Review', style: Theme.of(context).textTheme.headline6),
                  OrderItemsList(items: cartItems),
                  
                  SizedBox(height: 24),
                  
                  SwitchListTile(
                    title: Text('Send as gift'),
                    value: isGift,
                    onChanged: (val) => setState(() => isGift = val),
                  ),
                  
                  if (isGift) ...[
                    TextFormField(
                      decoration: InputDecoration(labelText: 'Recipient Name'),
                      validator: (val) => val?.isEmpty ?? true ? 'Required' : null,
                    ),
                    TextFormField(
                      decoration: InputDecoration(labelText: 'Recipient Phone'),
                      validator: (val) => Validators.phone(val),
                    ),
                    TextFormField(
                      decoration: InputDecoration(labelText: 'Gift Message (Optional)'),
                      maxLines: 3,
                    ),
                  ],
                  
                  SizedBox(height: 24),
                  
                  OrderSummaryCard(
                    subtotal: subtotal,
                    serviceFee: subtotal * 0.08,
                    total: subtotal * 1.08,
                  ),
                  
                  CheckboxListTile(
                    title: Text.rich(
                      TextSpan(
                        text: 'I agree to ',
                        children: [
                          TextSpan(
                            text: 'Terms & Conditions',
                            style: TextStyle(color: Colors.blue),
                            recognizer: TapGestureRecognizer()
                              ..onTap = () => _showTerms(),
                          ),
                        ],
                      ),
                    ),
                    value: termsAccepted,
                    onChanged: (val) => setState(() => termsAccepted = val ?? false),
                  ),
                ],
              ),
            ),
          ),
          bottomNavigationBar: Padding(
            padding: EdgeInsets.all(16),
            child: ElevatedButton(
              onPressed: termsAccepted && state is! CheckoutLoading
                  ? () => _proceedToPayment()
                  : null,
              child: state is CheckoutLoading
                  ? CircularProgressIndicator(color: Colors.white)
                  : Text('Proceed to Payment'),
            ),
          ),
        );
      },
    );
  }
  
  void _proceedToPayment() {
    if (_formKey.currentState!.validate()) {
      context.read<CheckoutBloc>().add(
        CreateOrder(
          items: cartItems,
          isGift: isGift,
          recipientInfo: isGift ? recipientData : null,
        ),
      );
    }
  }
}
```

Payment Method Screen:

1. Available Methods:
   - ABA Pay (logo + "Recommended" badge)
   - Wing Money (logo)
   - Pi Pay (logo)
   - KHQR/Bakong (logo)

2. Each Payment Method Tile:
   - Logo image
   - Method name
   - Radio button selection
   - Processing fee info (if any)

3. Selected Method Highlight:
   - Blue border or background
   - Checkmark icon

4. CTA Button:
   - "Continue to Payment" button
   - Disabled if no method selected

```dart
// payment_method_screen.dart
class PaymentMethodScreen extends StatefulWidget {
  final String orderId;
  
  const PaymentMethodScreen({required this.orderId});
  
  @override
  _PaymentMethodScreenState createState() => _PaymentMethodScreenState();
}

class _PaymentMethodScreenState extends State<PaymentMethodScreen> {
  PaymentMethod? selectedMethod;
  
  final methods = [
    PaymentMethodInfo(
      method: PaymentMethod.ABA_PAY,
      name: 'ABA Pay',
      logo: 'assets/images/aba_logo.png',
      isRecommended: true,
    ),
    PaymentMethodInfo(
      method: PaymentMethod.WING,
      name: 'Wing Money',
      logo: 'assets/images/wing_logo.png',
    ),
    PaymentMethodInfo(
      method: PaymentMethod.PI_PAY,
      name: 'Pi Pay',
      logo: 'assets/images/pipay_logo.png',
    ),
    PaymentMethodInfo(
      method: PaymentMethod.KHQR,
      name: 'KHQR (Bakong)',
      logo: 'assets/images/khqr_logo.png',
    ),
  ];
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Select Payment Method')),
      body: BlocConsumer<PaymentBloc, PaymentState>(
        listener: (context, state) {
          if (state is PaymentInitiated) {
            if (state.requiresWebView) {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => PaymentWebViewScreen(
                    url: state.paymentUrl!,
                    orderId: widget.orderId,
                  ),
                ),
              );
            } else {
              // Show QR code for KHQR payment
              _showQRCodeDialog(state.qrCodeData!);
            }
          } else if (state is PaymentError) {
            _showErrorDialog(state.message);
          }
        },
        builder: (context, state) {
          return Column(
            children: [
              Expanded(
                child: ListView.builder(
                  padding: EdgeInsets.all(16),
                  itemCount: methods.length,
                  itemBuilder: (context, index) {
                    return PaymentMethodTile(
                      method: methods[index],
                      isSelected: selectedMethod == methods[index].method,
                      onTap: () => setState(() => selectedMethod = methods[index].method),
                    );
                  },
                ),
              ),
              Padding(
                padding: EdgeInsets.all(16),
                child: ElevatedButton(
                  onPressed: selectedMethod != null && state is! PaymentLoading
                      ? () => _initiatePayment()
                      : null,
                  child: state is PaymentLoading
                      ? CircularProgressIndicator(color: Colors.white)
                      : Text('Continue to Payment'),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
  
  void _initiatePayment() {
    context.read<PaymentBloc>().add(
      InitiatePayment(
        orderId: widget.orderId,
        paymentMethod: selectedMethod!,
      ),
    );
  }
  
  void _showQRCodeDialog(String qrData) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => QRCodePaymentDialog(
        qrData: qrData,
        orderId: widget.orderId,
      ),
    );
  }
}
```

Payment WebView Screen:

1. Display payment gateway page in WebView
2. Intercept navigation to detect success/cancel URLs
3. Show loading indicator while page loads
4. Handle success/failure redirects
5. Deep link back to app on completion

```dart
// payment_webview_screen.dart
class PaymentWebViewScreen extends StatefulWidget {
  final String url;
  final String orderId;
  
  @override
  _PaymentWebViewScreenState createState() => _PaymentWebViewScreenState();
}

class _PaymentWebViewScreenState extends State<PaymentWebViewScreen> {
  late final WebViewController controller;
  bool isLoading = true;
  
  @override
  void initState() {
    super.initState();
    controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (_) => setState(() => isLoading = true),
          onPageFinished: (_) => setState(() => isLoading = false),
          onNavigationRequest: (request) {
            final uri = Uri.parse(request.url);
            
            // Detect success return URL
            if (uri.path.contains('/payments/return/success')) {
              _handlePaymentSuccess();
              return NavigationDecision.prevent;
            }
            
            // Detect cancel return URL
            if (uri.path.contains('/payments/return/cancel')) {
              _handlePaymentCancel();
              return NavigationDecision.prevent;
            }
            
            // Detect error return URL
            if (uri.path.contains('/payments/return/error')) {
              _handlePaymentError();
              return NavigationDecision.prevent;
            }
            
            return NavigationDecision.navigate;
          },
        ),
      )
      ..loadRequest(Uri.parse(widget.url));
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Complete Payment'),
        leading: IconButton(
          icon: Icon(Icons.close),
          onPressed: () => _confirmCancel(),
        ),
      ),
      body: Stack(
        children: [
          WebViewWidget(controller: controller),
          if (isLoading)
            Center(child: CircularProgressIndicator()),
        ],
      ),
    );
  }
  
  void _handlePaymentSuccess() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => OrderConfirmationScreen(orderId: widget.orderId),
      ),
    );
  }
  
  void _handlePaymentCancel() {
    Navigator.pop(context);
    _showMessage('Payment cancelled');
  }
  
  void _handlePaymentError() {
    Navigator.pop(context);
    _showMessage('Payment failed. Please try again.');
  }
  
  void _confirmCancel() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Cancel Payment?'),
        content: Text('Are you sure you want to cancel this payment?'),
        actions: [
          TextButton(
            child: Text('No'),
            onPressed: () => Navigator.pop(context),
          ),
          TextButton(
            child: Text('Yes, Cancel'),
            onPressed: () {
              Navigator.pop(context); // Close dialog
              Navigator.pop(context); // Close webview
            },
          ),
        ],
      ),
    );
  }
}
```

Order Confirmation Screen:

1. Success Animation:
   - Lottie animation (checkmark)
   - "Payment Successful!" text

2. Order Summary:
   - Order number
   - Date & time
   - Vouchers purchased
   - Amount paid

3. CTA Buttons:
   - "View My Vouchers" (navigate to wallet)
   - "Continue Shopping" (navigate to home)
   - "View Receipt" (download or share PDF)

4. Background Process:
   - Poll payment status if not confirmed
   - Update order status
   - Trigger wallet voucher generation

Testing:
- Test all payment methods with sandbox credentials
- Test success/failure scenarios
- Test network interruption during payment
- Test cart persistence
- Test gift purchase flow
```

### Prompt 3.5: Wallet & QR Code Display - Consumer App
```
Implement Wallet feature for managing purchased vouchers:

Screens:
1. Wallet Screen (List of vouchers)
2. Voucher QR Code Screen (Full-screen QR for redemption)
3. Gift Voucher Screen
4. Redemption History

File Structure:
features/wallet/
├── data/...
├── domain/...
└── presentation/
    ├── bloc/
    │   ├── wallet_bloc.dart
    │   ├── voucher_qr_bloc.dart
    │   └── gift_bloc.dart
    ├── screens/
    │   ├── wallet_screen.dart
    │   ├── voucher_qr_screen.dart
    │   ├── gift_voucher_screen.dart
    │   └── redemption_history_screen.dart
    └── widgets/
        ├── wallet_voucher_card.dart
        ├── qr_code_display.dart
        ├── pin_display.dart
        └── expiry_indicator.dart

Wallet Screen Implementation:

1. Tab Bar:
   - Active (unused vouchers)
   - Redeemed (used vouchers)
   - Expired (past expiry date)
   - Gifted (sent to others)

2. Each Voucher Card:
   - Voucher image
   - Merchant logo overlay
   - Title
   - Value/amount
   - Expiry date with countdown
   - "Expiring soon" badge if < 7 days
   - Tap to view QR code

3. Empty States:
   - Different message for each tab
   - CTA button to browse vouchers

4. Pull to Refresh:
   - Sync with server
   - Update voucher statuses

```dart
// wallet_screen.dart
class WalletScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4,
      child: Scaffold(
        appBar: AppBar(
          title: Text('My Wallet'),
          bottom: TabBar(
            tabs: [
              Tab(text: 'Active'),
              Tab(text: 'Redeemed'),
              Tab(text: 'Expired'),
              Tab(text: 'Gifted'),
            ],
          ),
        ),
        body: BlocBuilder<WalletBloc, WalletState>(
          builder: (context, state) {
            if (state is WalletLoading) return LoadingWidget();
            if (state is WalletError) return ErrorWidget(state.message);
            if (state is WalletLoaded) {
              return TabBarView(
                children: [
                  _buildVoucherList(state.activeVouchers, 'active'),
                  _buildVoucherList(state.redeemedVouchers, 'redeemed'),
                  _buildVoucherList(state.expiredVouchers, 'expired'),
                  _buildVoucherList(state.giftedVouchers, 'gifted'),
                ],
              );
            }
            return SizedBox();
          },
        ),
      ),
    );
  }
  
  Widget _buildVoucherList(List<WalletVoucher> vouchers, String type) {
    if (vouchers.isEmpty) {
      return EmptyWalletState(type: type);
    }
    
    return RefreshIndicator(
      onRefresh: () async {
        context.read<WalletBloc>().add(RefreshWallet());
      },
      child: ListView.builder(
        padding: EdgeInsets.all(16),
        itemCount: vouchers.length,
        itemBuilder: (context, index) {
          return WalletVoucherCard(
            voucher: vouchers[index],
            onTap: () => _openQRScreen(context, vouchers[index]),
            onGift: type == 'active' ? () => _giftVoucher(context, vouchers[index]) : null,
          );
        },
      ),
    );
  }
  
  void _openQRScreen(BuildContext context, WalletVoucher voucher) {
    if (voucher.status == VoucherStatus.ACTIVE) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => VoucherQRScreen(voucherId: voucher.id),
        ),
      );
    }
  }
  
  void _giftVoucher(BuildContext context, WalletVoucher voucher) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => GiftVoucherScreen(voucher: voucher),
      ),
    );
  }
}
```

Voucher QR Code Screen:

1. Full-Screen Display:
   - Large QR code (occupies most of screen)
   - High contrast (black on white)
   - Brightness auto-increased for scanning

2. Voucher Info (top):
   - Merchant name and logo
   - Voucher title
   - Value

3. PIN Code Display (below QR):
   - "Or use PIN: XXXXXX" text
   - Copy button

4. Instructions:
   - "Show this code to merchant to redeem"
   - Expiry countdown timer

5. Actions:
   - "How to Use" info button
   - Gift button
   - Close button

```dart
// voucher_qr_screen.dart
class VoucherQRScreen extends StatefulWidget {
  final String voucherId;
  
  @override
  _VoucherQRScreenState createState() => _VoucherQRScreenState();
}

class _VoucherQRScreenState extends State<VoucherQRScreen> {
  double screenBrightness = 1.0;
  
  @override
  void initState() {
    super.initState();
    _setMaxBrightness();
  }
  
  @override
  void dispose() {
    _restoreBrightness();
    super.dispose();
  }
  
  Future<void> _setMaxBrightness() async {
    // Save current brightness
    screenBrightness = await ScreenBrightness().current;
    // Set to max
    await ScreenBrightness().setScreenBrightness(1.0);
  }
  
  Future<void> _restoreBrightness() async {
    await ScreenBrightness().setScreenBrightness(screenBrightness);
  }
  
  @override
  Widget build(BuildContext context) {
    return BlocBuilder<VoucherQRBloc, VoucherQRState>(
      builder: (context, state) {
        if (state is VoucherQRLoaded) {
          return Scaffold(
            backgroundColor: Colors.white,
            appBar: AppBar(
              backgroundColor: Colors.white,
              elevation: 0,
              leading: IconButton(
                icon: Icon(Icons.close, color: Colors.black),
                onPressed: () => Navigator.pop(context),
              ),
              actions: [
                IconButton(
                  icon: Icon(Icons.info_outline, color: Colors.black),
                  onPressed: () => _showInstructions(),
                ),
              ],
            ),
            body: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // Merchant Info
                  MerchantHeader(merchant: state.voucher.merchant),
                  
                  SizedBox(height: 20),
                  
                  // QR Code
                  Container(
                    padding: EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black12,
                          blurRadius: 10,
                          spreadRadius: 5,
                        ),
                      ],
                    ),
                    child: QrImageView(
                      data: state.qrData,
                      version: QrVersions.auto,
                      size: 250.0,
                      errorCorrectionLevel: QrErrorCorrectLevel.H,
                    ),
                  ),
                  
                  SizedBox(height: 30),
                  
                  // PIN Code
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                    decoration: BoxDecoration(
                      color: Colors.grey[100],
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          'PIN: ${state.voucher.pinCode}',
                          style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 2,
                          ),
                        ),
                        SizedBox(width: 10),
                        IconButton(
                          icon: Icon(Icons.copy),
                          onPressed: () => _copyPin(state.voucher.pinCode),
                        ),
                      ],
                    ),
                  ),
                  
                  SizedBox(height: 20),
                  
                  // Expiry Info
                  ExpiryCountdown(expiresAt: state.voucher.expiresAt),
                  
                  SizedBox(height: 30),
                  
                  // Instructions
                  Text(
                    'Show this code to merchant to redeem',
                    style: TextStyle(fontSize: 16, color: Colors.grey[600]),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
            bottomNavigationBar: Padding(
              padding: EdgeInsets.all(16),
              child: ElevatedButton.icon(
                onPressed: () => _giftVoucher(),
                icon: Icon(Icons.card_giftcard),
                label: Text('Gift This Voucher'),
                style: ElevatedButton.styleFrom(
                  padding: EdgeInsets.symmetric(vertical: 15),
                ),
              ),
            ),
          );
        }
        return LoadingWidget();
      },
    );
  }
  
  void _copyPin(String pin) {
    Clipboard.setData(ClipboardData(text: pin));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('PIN copied to clipboard')),
    );
  }
  
  void _showInstructions() {
    showModalBottomSheet(
      context: context,
      builder: (_) => HowToUseSheet(voucher: voucher),
    );
  }
  
  void _giftVoucher() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => GiftVoucherScreen(voucher: voucher),
      ),
    );
  }
}
```

Gift Voucher Screen:

1. Form Fields:
   - Recipient selection:
     * From contacts (with permission)
     * Manual entry (phone or email)
   - Gift message (optional, max 200 chars)
   - Character counter

2. Preview:
   - Show how gift will appear to recipient
   - Gift card design with message

3. Confirmation:
   - Review recipient info
   - Confirm button
   - "Gift will be sent immediately" notice

```dart
// gift_voucher_screen.dart
class GiftVoucherScreen extends StatefulWidget {
  final WalletVoucher voucher;
  
  @override
  _GiftVoucherScreenState createState() => _GiftVoucherScreenState();
}

class _GiftVoucherScreenState extends State<GiftVoucherScreen> {
  final _formKey = GlobalKey<FormState>();
  final _messageController = TextEditingController();
  String? recipientPhone;
  String? recipientEmail;
  bool _sendingGift = false;
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Gift Voucher')),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Voucher Preview
              VoucherPreviewCard(voucher: widget.voucher),
              
              SizedBox(height: 24),
              
              Text(
                'Recipient',
                style: Theme.of(context).textTheme.headline6,
              ),
              
              SizedBox(height: 12),
              
              // Recipient Input Options
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: () => _selectFromContacts(),
                      icon: Icon(Icons.contacts),
                      label: Text('From Contacts'),
                    ),
                  ),
                ],
              ),
              
              SizedBox(height: 12),
              
              Text('OR', textAlign: TextAlign.center),
              
              SizedBox(height: 12),
              
              // Manual Entry
              TextFormField(
                decoration: InputDecoration(
                  labelText: 'Phone Number',
                  hintText: '+855 12 345 678',
                  prefixIcon: Icon(Icons.phone),
                ),
                keyboardType: TextInputType.phone,
                validator: Validators.phone,
                onSaved: (val) => recipientPhone = val,
              ),
              
              SizedBox(height: 12),
              
              Text('OR', textAlign: TextAlign.center),
              
              SizedBox(height: 12),
              
              TextFormField(
                decoration: InputDecoration(
                  labelText: 'Email Address',
                  hintText: 'recipient@example.com',
                  prefixIcon: Icon(Icons.email),
                ),
                keyboardType: TextInputType.emailAddress,
                validator: Validators.email,
                onSaved: (val) => recipientEmail = val,
              ),
              
              SizedBox(height: 24),
              
              // Gift Message
              Text(
                'Gift Message (Optional)',
                style: Theme.of(context).textTheme.headline6,
              ),
              
              SizedBox(height: 12),
              
              TextFormField(
                controller: _messageController,
                decoration: InputDecoration(
                  hintText: 'Write a personal message...',
                  border: OutlineInputBorder(),
                  counterText: '${_messageController.text.length}/200',
                ),
                maxLines: 4,
                maxLength: 200,
                onChanged: (_) => setState(() {}),
              ),
              
              SizedBox(height: 24),
              
              // Preview
              GiftPreviewCard(
                voucher: widget.voucher,
                message: _messageController.text,
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: Padding(
        padding: EdgeInsets.all(16),
        child: ElevatedButton(
          onPressed: _sendingGift ? null : () => _confirmGift(),
          child: _sendingGift
              ? CircularProgressIndicator(color: Colors.white)
              : Text('Send Gift'),
        ),
      ),
    );
  }
  
  Future<void> _selectFromContacts() async {
    // Request permission
    final permission = await Permission.contacts.request();
    if (permission.isGranted) {
      // Use contact_picker package to select contact
      final contact = await FlutterContactPicker.pickPhoneContact();
      if (contact != null) {
        setState(() {
          recipientPhone = contact.phoneNumber?.number;
        });
      }
    }
  }
  
  void _confirmGift() {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      
      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: Text('Confirm Gift'),
          content: Text(
            'Send this voucher to ${recipientPhone ?? recipientEmail}?\n\n'
            'This action cannot be undone.',
          ),
          actions: [
            TextButton(
              child: Text('Cancel'),
              onPressed: () => Navigator.pop(context),
            ),
            ElevatedButton(
              child: Text('Send Gift'),
              onPressed: () {
                Navigator.pop(context);
                _sendGift();
              },
            ),
          ],
        ),
      );
    }
  }
  
  Future<void> _sendGift() async {
    setState(() => _sendingGift = true);
    
    try {
      await context.read<GiftBloc>().sendGift(
        voucherId: widget.voucher.id,
        recipientPhone: recipientPhone,
        recipientEmail: recipientEmail,
        message: _messageController.text,
      );
      
      Navigator.pop(context);
      _showSuccess();
    } catch (e) {
      _showError(e.toString());
    } finally {
      setState(() => _sendingGift = false);
    }
  }
  
  void _showSuccess() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Gift Sent!'),
        content: Text('Your gift voucher has been sent successfully.'),
        actions: [
          TextButton(
            child: Text('OK'),
            onPressed: () => Navigator.pop(context),
          ),
        ],
      ),
    );
  }
}
```

Testing:
- Test QR code generation and scanning
- Test PIN validation
- Test gift flow with different recipient types
- Test screen brightness adjustment
- Test offline mode (cached vouchers)
- Test expiry notifications
```

---

## PHASE 4: Admin Portal

### Prompt 4.1: Admin Portal Setup - Angular
```
Create production-ready Angular Admin Portal (kado24-admin-portal):

Project Setup:
```bash
ng new kado24-admin-portal --routing --style=scss
cd kado24-admin-portal
ng add @angular/material
```

Project Structure:
src/
├── app/
│   ├── core/
│   │   ├── guards/ (Auth guard, role guard)
│   │   ├── interceptors/ (Auth, error, loading)
│   │   ├── services/ (API services)
│   │   └── models/ (TypeScript interfaces)
│   ├── shared/
│   │   ├── components/ (Reusable UI components)
│   │   ├── directives/
│   │   └── pipes/
│   ├── features/
│   │   ├── auth/ (Login, reset password)
│   │   ├── dashboard/
│   │   ├── merchants/ (Merchant management)
│   │   ├── vouchers/ (Voucher moderation)
│   │   ├── orders/ (Order monitoring)
│   │   ├── users/ (User management)
│   │   ├── analytics/ (Reports & analytics)
│   │   └── settings/
│   ├── layout/
│   │   ├── sidebar/
│   │   ├── header/
│   │   └── footer/
│   └── app-routing.module.ts
├── assets/
├── environments/
└── styles/ (Global SCSS)

Dependencies (package.json):
```json
{
  "dependencies": {
    "@angular/animations": "^17.0.0",
    "@angular/cdk": "^17.0.0",
    "@angular/common": "^17.0.0",
    "@angular/compiler": "^17.0.0",
    "@angular/core": "^17.0.0",
    "@angular/forms": "^17.0.0",
    "@angular/material": "^17.0.0",
    "@angular/platform-browser": "^17.0.0",
    "@angular/router": "^17.0.0",
    "chart.js": "^4.4.0",
    "ng2-charts": "^5.0.0",
    "ngx-pagination": "^6.0.3",
    "ngx-toastr": "^18.0.0",
    "rxjs": "^7.8.0"
  }
}
```

Key Features (15+ screens):
1. Dashboard (Analytics overview)
2. Merchant Management (Approval, verification, suspension)
3. Voucher Moderation (Approve/reject vouchers)
4. User Management (View, suspend, ban users)
5. Order Monitoring (Track all orders and transactions)
6. Financial Reports (Revenue, payouts, commissions)
7. Analytics & Insights
8. Platform Settings
9. Fraud Detection Alerts

Angular Material Components to Use:
- mat-sidenav (Sidebar navigation)
- mat-toolbar (Top navigation)
- mat-card (Content cards)
- mat-table + mat-paginator (Data tables)
- mat-form-field (Forms)
- mat-dialog (Modals)
- mat-snackbar (Notifications)
- mat-tabs (Tabbed interfaces)
- mat-menu (Dropdown menus)

Routing Configuration:
```typescript
// app-routing.module.ts
const routes: Routes = [
  { path: 'login', component: LoginComponent },
  {
    path: '',
    component: LayoutComponent,
    canActivate: [AuthGuard],
    children: [
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
      { 
        path: 'dashboard', 
        loadChildren: () => import('./features/dashboard/dashboard.module').then(m => m.DashboardModule)
      },
      { 
        path: 'merchants', 
        loadChildren: () => import('./features/merchants/merchants.module').then(m => m.MerchantsModule),
        canActivate: [RoleGuard],
        data: { roles: ['ADMIN', 'SUPER_ADMIN'] }
      },
      // ... more routes
    ]
  },
  { path: '**', redirectTo: 'dashboard' }
];
```

Auth Interceptor:
```typescript
// core/interceptors/auth.interceptor.ts
@Injectable()
export class AuthInterceptor implements HttpInterceptor {
  constructor(private authService: AuthService) {}
  
  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const token = this.authService.getToken();
    
    if (token) {
      req = req.clone({
        setHeaders: {
          Authorization: `Bearer ${token}`
        }
      });
    }
    
    return next.handle(req).pipe(
      catchError((error: HttpErrorResponse) => {
        if (error.status === 401) {
          this.authService.logout();
          window.location.href = '/login';
        }
        return throwError(() => error);
      })
    );
  }
}
```

Best Practices:
- Lazy loading for all feature modules
- Reactive forms with validation
- RxJS for state management
- Material Design theme customization
- Responsive design (mobile, tablet, desktop)
- Error handling with toast notifications
- Loading states for async operations
- Role-based access control
```

### Prompt 4.2: Dashboard & Analytics - Admin Portal
```
Implement comprehensive Dashboard with real-time analytics:

Components:
1. Overview Cards (Key metrics)
2. Revenue Chart (Line/bar chart)
3. Order Statistics (Pie chart)
4. Recent Transactions Table
5. Top Merchants Table
6. User Growth Chart
7. Alerts & Notifications Panel

File Structure:
features/dashboard/
├── components/
│   ├── metric-card/
│   ├── revenue-chart/
│   ├── order-stats-chart/
│   ├── recent-transactions/
│   ├── top-merchants/
│   └── alerts-panel/
├── services/
│   └── dashboard.service.ts
├── models/
│   └── dashboard.model.ts
└── dashboard.component.ts

Dashboard Component:
```typescript
// dashboard.component.ts
import { Component, OnInit } from '@angular/core';
import { DashboardService } from './services/dashboard.service';
import { DashboardStats } from './models/dashboard.model';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  stats: DashboardStats | null = null;
  loading = true;
  
  // Date range filter
  dateRange = {
    start: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000), // Last 30 days
    end: new Date()
  };
  
  constructor(private dashboardService: DashboardService) {}
  
  ngOnInit(): void {
    this.loadDashboard();
    
    // Auto-refresh every 5 minutes
    setInterval(() => this.loadDashboard(), 5 * 60 * 1000);
  }
  
  loadDashboard(): void {
    this.loading = true;
    this.dashboardService.getStats(this.dateRange).subscribe({
      next: (data) => {
        this.stats = data;
        this.loading = false;
      },
      error: (err) => {
        console.error('Error loading dashboard:', err);
        this.loading = false;
      }
    });
  }
  
  onDateRangeChange(range: { start: Date, end: Date }): void {
    this.dateRange = range;
    this.loadDashboard();
  }
}
```

HTML Template:
```html
<!-- dashboard.component.html -->
<div class="dashboard-container">
  <div class="dashboard-header">
    <h1>Dashboard</h1>
    <mat-form-field appearance="outline">
      <mat-label>Date Range</mat-label>
      <mat-date-range-input [rangePicker]="picker">
        <input matStartDate [(ngModel)]="dateRange.start" placeholder="Start date">
        <input matEndDate [(ngModel)]="dateRange.end" placeholder="End date" (dateChange)="onDateRangeChange(dateRange)">
      </mat-date-range-input>
      <mat-datepicker-toggle matSuffix [for]="picker"></mat-datepicker-toggle>
      <mat-date-range-picker #picker></mat-date-range-picker>
    </mat-form-field>
  </div>
  
  <!-- Loading State -->
  <div *ngIf="loading" class="loading-spinner">
    <mat-spinner></mat-spinner>
  </div>
  
  <!-- Metrics Cards -->
  <div *ngIf="!loading && stats" class="metrics-grid">
    <app-metric-card
      title="Total Revenue"
      [value]="stats.totalRevenue"
      icon="attach_money"
      [change]="stats.revenueChange"
      format="currency"
    ></app-metric-card>
    
    <app-metric-card
      title="Total Orders"
      [value]="stats.totalOrders"
      icon="shopping_cart"
      [change]="stats.ordersChange"
      format="number"
    ></app-metric-card>
    
    <app-metric-card
      title="Active Users"
      [value]="stats.activeUsers"
      icon="people"
      [change]="stats.usersChange"
      format="number"
    ></app-metric-card>
    
    <app-metric-card
      title="Active Merchants"
      [value]="stats.activeMerchants"
      icon="store"
      [change]="stats.merchantsChange"
      format="number"
    ></app-metric-card>
  </div>
  
  <!-- Charts Row -->
  <div *ngIf="!loading && stats" class="charts-row">
    <mat-card class="chart-card">
      <mat-card-header>
        <mat-card-title>Revenue Trend</mat-card-title>
      </mat-card-header>
      <mat-card-content>
        <app-revenue-chart [data]="stats.revenueChart"></app-revenue-chart>
      </mat-card-content>
    </mat-card>
    
    <mat-card class="chart-card">
      <mat-card-header>
        <mat-card-title>Order Status Distribution</mat-card-title>
      </mat-card-header>
      <mat-card-content>
        <app-order-stats-chart [data]="stats.orderStats"></app-order-stats-chart>
      </mat-card-content>
    </mat-card>
  </div>
  
  <!-- Tables Row -->
  <div *ngIf="!loading && stats" class="tables-row">
    <mat-card class="table-card">
      <mat-card-header>
        <mat-card-title>Recent Transactions</mat-card-title>
      </mat-card-header>
      <mat-card-content>
        <app-recent-transactions [transactions]="stats.recentTransactions"></app-recent-transactions>
      </mat-card-content>
    </mat-card>
    
    <mat-card class="table-card">
      <mat-card-header>
        <mat-card-title>Top Performing Merchants</mat-card-title>
      </mat-card-header>
      <mat-card-content>
        <app-top-merchants [merchants]="stats.topMerchants"></app-top-merchants>
      </mat-card-content>
    </mat-card>
  </div>
  
  <!-- Alerts Panel -->
  <div *ngIf="!loading && stats" class="alerts-section">
    <app-alerts-panel [alerts]="stats.alerts"></app-alerts-panel>
  </div>
</div>
```

Metric Card Component:
```typescript
// metric-card.component.ts
import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-metric-card',
  template: `
    <mat-card class="metric-card">
      <div class="metric-icon">
        <mat-icon>{{ icon }}</mat-icon>
      </div>
      <div class="metric-content">
        <div class="metric-label">{{ title }}</div>
        <div class="metric-value">{{ formattedValue }}</div>
        <div class="metric-change" [class.positive]="change >= 0" [class.negative]="change < 0">
          <mat-icon>{{ change >= 0 ? 'trending_up' : 'trending_down' }}</mat-icon>
          {{ Math.abs(change) }}% from last period
        </div>
      </div>
    </mat-card>
  `,
  styles: [`
    .metric-card {
      display: flex;
      align-items: center;
      padding: 20px;
      height: 120px;
    }
    .metric-icon {
      font-size: 48px;
      margin-right: 20px;
      color: #3f51b5;
    }
    .metric-icon mat-icon {
      font-size: 48px;
      width: 48px;
      height: 48px;
    }
    .metric-value {
      font-size: 32px;
      font-weight: bold;
      margin: 5px 0;
    }
    .metric-change {
      display: flex;
      align-items: center;
      font-size: 14px;
    }
    .metric-change.positive {
      color: #4caf50;
    }
    .metric-change.negative {
      color: #f44336;
    }
  `]
})
export class MetricCardComponent {
  @Input() title = '';
  @Input() value: number = 0;
  @Input() icon = '';
  @Input() change: number = 0;
  @Input() format: 'currency' | 'number' | 'percent' = 'number';
  
  Math = Math;
  
  get formattedValue(): string {
    switch (this.format) {
      case 'currency':
        return `$${this.value.toLocaleString('en-US', { minimumFractionDigits: 2 })}`;
      case 'percent':
        return `${this.value}%`;
      default:
        return this.value.toLocaleString('en-US');
    }
  }
}
```

Revenue Chart Component (using Chart.js):
```typescript
// revenue-chart.component.ts
import { Component, Input, OnChanges } from '@angular/core';
import { ChartConfiguration } from 'chart.js';

@Component({
  selector: 'app-revenue-chart',
  template: `
    <canvas baseChart
      [data]="lineChartData"
      [options]="lineChartOptions"
      [type]="'line'">
    </canvas>
  `
})
export class RevenueChartComponent implements OnChanges {
  @Input() data: any;
  
  lineChartData: ChartConfiguration['data'] = {
    datasets: [],
    labels: []
  };
  
  lineChartOptions: ChartConfiguration['options'] = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: true,
        position: 'top'
      }
    },
    scales: {
      y: {
        beginAtZero: true,
        ticks: {
          callback: function(value) {
            return '$' + value.toLocaleString();
          }
        }
      }
    }
  };
  
  ngOnChanges(): void {
    if (this.data) {
      this.lineChartData = {
        labels: this.data.labels,
        datasets: [
          {
            data: this.data.values,
            label: 'Revenue',
            fill: true,
            tension: 0.4,
            borderColor: '#3f51b5',
            backgroundColor: 'rgba(63, 81, 181, 0.1)'
          }
        ]
      };
    }
  }
}
```

Dashboard Service:
```typescript
// services/dashboard.service.ts
import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '@environments/environment';
import { DashboardStats } from '../models/dashboard.model';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {
  private apiUrl = `${environment.apiUrl}/api/admin/dashboard`;
  
  constructor(private http: HttpClient) {}
  
  getStats(dateRange: { start: Date, end: Date }): Observable<DashboardStats> {
    const params = new HttpParams()
      .set('startDate', dateRange.start.toISOString())
      .set('endDate', dateRange.end.toISOString());
      
    return this.http.get<DashboardStats>(`${this.apiUrl}/stats`, { params });
  }
  
  exportReport(format: 'pdf' | 'excel', dateRange: { start: Date, end: Date }): Observable<Blob> {
    const params = new HttpParams()
      .set('format', format)
      .set('startDate', dateRange.start.toISOString())
      .set('endDate', dateRange.end.toISOString());
      
    return this.http.get(`${this.apiUrl}/export`, {
      params,
      responseType: 'blob'
    });
  }
}
```

SCSS Styling:
```scss
// dashboard.component.scss
.dashboard-container {
  padding: 24px;
}

.dashboard-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 24px;
  
  h1 {
    margin: 0;
    font-size: 32px;
    font-weight: 500;
  }
}

.metrics-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 20px;
  margin-bottom: 24px;
}

.charts-row {
  display: grid;
  grid-template-columns: 2fr 1fr;
  gap: 20px;
  margin-bottom: 24px;
  
  .chart-card {
    min-height: 400px;
  }
}

.tables-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 20px;
  margin-bottom: 24px;
}

.loading-spinner {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 400px;
}

@media (max-width: 1024px) {
  .charts-row, .tables-row {
    grid-template-columns: 1fr;
  }
}
```

Testing:
- Unit tests for dashboard service
- Component tests for all dashboard components
- E2E tests for dashboard loading and filtering
```

---

## PHASE 5: Integrations & Testing

### Prompt 5.1: Kafka Event Integration
```
Implement comprehensive Kafka event streaming across all microservices:

Common Kafka Configuration (for all Spring Boot services):

```yaml
# application.yml
spring:
  kafka:
    bootstrap-servers: ${KAFKA_BOOTSTRAP_SERVERS:localhost:9092}
    producer:
      key-serializer: org.apache.kafka.common.serialization.StringSerializer
      value-serializer: org.springframework.kafka.support.serializer.JsonSerializer
      properties:
        spring.json.add.type.headers: false
      acks: all
      retries: 3
    consumer:
      key-deserializer: org.apache.kafka.common.serialization.StringDeserializer
      value-deserializer: org.springframework.kafka.support.serializer.JsonDeserializer
      properties:
        spring.json.trusted.packages: com.kado24.*
      auto-offset-reset: earliest
      enable-auto-commit: false
    listener:
      ack-mode: manual
```

Kafka Configuration Class:
```java
// config/KafkaConfig.java
@Configuration
@EnableKafka
public class KafkaConfig {
    
    @Value("${spring.kafka.bootstrap-servers}")
    private String bootstrapServers;
    
    @Bean
    public ProducerFactory<String, Object> producerFactory() {
        Map<String, Object> configProps = new HashMap<>();
        configProps.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        configProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        configProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);
        configProps.put(ProducerConfig.ACKS_CONFIG, "all");
        configProps.put(ProducerConfig.RETRIES_CONFIG, 3);
        configProps.put(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG, true);
        return new DefaultKafkaProducerFactory<>(configProps);
    }
    
    @Bean
    public KafkaTemplate<String, Object> kafkaTemplate() {
        return new KafkaTemplate<>(producerFactory());
    }
    
    @Bean
    public ConsumerFactory<String, Object> consumerFactory() {
        Map<String, Object> props = new HashMap<>();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, JsonDeserializer.class);
        props.put(JsonDeserializer.TRUSTED_PACKAGES, "com.kado24.*");
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false);
        return new DefaultKafkaConsumerFactory<>(props);
    }
    
    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, Object> kafkaListenerContainerFactory() {
        ConcurrentKafkaListenerContainerFactory<String, Object> factory = 
            new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(consumerFactory());
        factory.getContainerProperties().setAckMode(AckMode.MANUAL);
        return factory;
    }
}
```

Event Models:
```java
// common/dto/kafka/OrderEvent.java
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OrderEvent {
    private String orderId;
    private String userId;
    private String voucherId;
    private String merchantId;
    private BigDecimal amount;
    private OrderStatus status;
    private LocalDateTime timestamp;
    private Map<String, String> metadata;
}

// common/dto/kafka/PaymentEvent.java
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PaymentEvent {
    private String paymentId;
    private String orderId;
    private BigDecimal amount;
    private PaymentMethod paymentMethod;
    private PaymentStatus status;
    private String gatewayTransactionId;
    private LocalDateTime timestamp;
}

// common/dto/kafka/RedemptionEvent.java
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RedemptionEvent {
    private String redemptionId;
    private String walletVoucherId;
    private String userId;
    private String merchantId;
    private String voucherId;
    private LocalDateTime redeemedAt;
    private String verificationMethod;
}
```

Event Producer Service:
```java
// service/EventPublisher.java
@Service
@Slf4j
public class EventPublisher {
    
    private final KafkaTemplate<String, Object> kafkaTemplate;
    
    public EventPublisher(KafkaTemplate<String, Object> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }
    
    public void publishOrderEvent(String topic, OrderEvent event) {
        try {
            ListenableFuture<SendResult<String, Object>> future = 
                kafkaTemplate.send(topic, event.getOrderId(), event);
                
            future.addCallback(
                result -> log.info("Published order event to {}: {}", topic, event.getOrderId()),
                ex -> log.error("Failed to publish order event to {}: {}", topic, ex.getMessage())
            );
        } catch (Exception e) {
            log.error("Error publishing order event", e);
        }
    }
    
    public void publishPaymentEvent(String topic, PaymentEvent event) {
        try {
            kafkaTemplate.send(topic, event.getPaymentId(), event);
            log.info("Published payment event to {}: {}", topic, event.getPaymentId());
        } catch (Exception e) {
            log.error("Error publishing payment event", e);
        }
    }
    
    public void publishRedemptionEvent(String topic, RedemptionEvent event) {
        try {
            kafkaTemplate.send(topic, event.getRedemptionId(), event);
            log.info("Published redemption event to {}: {}", topic, event.getRedemptionId());
        } catch (Exception e) {
            log.error("Error publishing redemption event", e);
        }
    }
}
```

Event Consumer Example (in Notification Service):
```java
// consumer/OrderEventConsumer.java
@Component
@Slf4j
public class OrderEventConsumer {
    
    private final NotificationService notificationService;
    
    public OrderEventConsumer(NotificationService notificationService) {
        this.notificationService = notificationService;
    }
    
    @KafkaListener(
        topics = "order-events",
        groupId = "notification-service-group",
        containerFactory = "kafkaListenerContainerFactory"
    )
    public void consumeOrderEvent(
        @Payload OrderEvent event,
        @Header(KafkaHeaders.RECEIVED_TOPIC) String topic,
        Acknowledgment acknowledgment
    ) {
        try {
            log.info("Received order event: {}", event.getOrderId());
            
            switch (event.getStatus()) {
                case PAID:
                    notificationService.sendOrderConfirmation(event);
                    break;
                case CANCELLED:
                    notificationService.sendOrderCancellation(event);
                    break;
                case COMPLETED:
                    notificationService.sendOrderCompletion(event);
                    break;
                default:
                    log.info("No notification needed for status: {}", event.getStatus());
            }
            
            // Manually acknowledge message
            acknowledgment.acknowledge();
            
        } catch (Exception e) {
            log.error("Error processing order event: {}", e.getMessage());
            // Don't acknowledge - message will be redelivered
        }
    }
    
    @KafkaListener(
        topics = "payment-events",
        groupId = "notification-service-group"
    )
    public void consumePaymentEvent(@Payload PaymentEvent event, Acknowledgment acknowledgment) {
        try {
            log.info("Received payment event: {}", event.getPaymentId());
            
            if (event.getStatus() == PaymentStatus.FAILED) {
                notificationService.sendPaymentFailure(event);
            }
            
            acknowledgment.acknowledge();
            
        } catch (Exception e) {
            log.error("Error processing payment event: {}", e.getMessage());
        }
    }
}
```

Event Consumer in Wallet Service:
```java
// consumer/PaymentEventConsumer.java
@Component
@Slf4j
public class PaymentEventConsumer {
    
    private final WalletVoucherService walletVoucherService;
    
    public PaymentEventConsumer(WalletVoucherService walletVoucherService) {
        this.walletVoucherService = walletVoucherService;
    }
    
    @KafkaListener(
        topics = "payment-events",
        groupId = "wallet-service-group"
    )
    public void consumePaymentEvent(@Payload PaymentEvent event, Acknowledgment acknowledgment) {
        try {
            log.info("Received payment event: {}", event.getPaymentId());
            
            if (event.getStatus() == PaymentStatus.SUCCESS) {
                // Activate wallet voucher
                walletVoucherService.activateVoucher(event.getOrderId());
                log.info("Activated wallet voucher for order: {}", event.getOrderId());
            }
            
            acknowledgment.acknowledge();
            
        } catch (Exception e) {
            log.error("Error activating wallet voucher: {}", e.getMessage());
            // Don't acknowledge - will retry
        }
    }
}
```

Kafka Topics Configuration:
```java
// config/KafkaTopicConfig.java
@Configuration
public class KafkaTopicConfig {
    
    @Value("${spring.kafka.bootstrap-servers}")
    private String bootstrapServers;
    
    @Bean
    public NewTopic orderEventsTopic() {
        return TopicBuilder.name("order-events")
            .partitions(3)
            .replicas(1)
            .build();
    }
    
    @Bean
    public NewTopic paymentEventsTopic() {
        return TopicBuilder.name("payment-events")
            .partitions(3)
            .replicas(1)
            .build();
    }
    
    @Bean
    public NewTopic notificationEventsTopic() {
        return TopicBuilder.name("notification-events")
            .partitions(5)
            .replicas(1)
            .build();
    }
    
    @Bean
    public NewTopic redemptionEventsTopic() {
        return TopicBuilder.name("redemption-events")
            .partitions(3)
            .replicas(1)
            .build();
    }
    
    @Bean
    public NewTopic analyticsEventsTopic() {
        return TopicBuilder.name("analytics-events")
            .partitions(5)
            .replicas(1)
            .build();
    }
    
    @Bean
    public NewTopic auditEventsTopic() {
        return TopicBuilder.name("audit-events")
            .partitions(3)
            .replicas(1)
            .build();
    }
}
```

Event Flow Examples:

1. Order Creation Flow:
   - Order Service → Publishes OrderEvent(status=PENDING) → order-events
   - Payment Service → Consumes → Initiates payment
   
2. Payment Completion Flow:
   - Payment Service → Publishes PaymentEvent(status=SUCCESS) → payment-events
   - Wallet Service → Consumes → Activates wallet voucher
   - Notification Service → Consumes → Sends confirmation
   - Analytics Service → Consumes → Records revenue
   
3. Redemption Flow:
   - Redemption Service → Publishes RedemptionEvent → redemption-events
   - Order Service → Consumes → Updates order status to COMPLETED
   - Analytics Service → Consumes → Updates merchant stats
   - Payout Service → Consumes → Calculates merchant payout

Error Handling:
- Dead Letter Queue (DLQ) for failed messages
- Retry mechanism with exponential backoff
- Manual acknowledgment to ensure at-least-once delivery
- Idempotency checks to prevent duplicate processing

Monitoring:
- Kafka metrics exposed via Prometheus
- Consumer lag monitoring
- Failed message tracking
```

### Prompt 5.2: Comprehensive Testing Strategy
```
Implement production-ready testing across all services:

Testing Pyramid:
1. Unit Tests (70%)
2. Integration Tests (20%)
3. E2E Tests (10%)

Maven Configuration (pom.xml):
```xml
<dependencies>
    <!-- Testing -->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-test</artifactId>
        <scope>test</scope>
    </dependency>
    <dependency>
        <groupId>org.testcontainers</groupId>
        <artifactId>testcontainers</artifactId>
        <version>1.19.3</version>
        <scope>test</scope>
    </dependency>
    <dependency>
        <groupId>org.testcontainers</groupId>
        <artifactId>postgresql</artifactId>
        <version>1.19.3</version>
        <scope>test</scope>
    </dependency>
    <dependency>
        <groupId>org.testcontainers</groupId>
        <artifactId>kafka</artifactId>
        <version>1.19.3</version>
        <scope>test</scope>
    </dependency>
    <dependency>
        <groupId>io.rest-assured</groupId>
        <artifactId>rest-assured</artifactId>
        <scope>test</scope>
    </dependency>
    <dependency>
        <groupId>org.mockito</groupId>
        <artifactId>mockito-core</artifactId>
        <scope>test</scope>
    </dependency>
</dependencies>

<build>
    <plugins>
        <plugin>
            <groupId>org.jacoco</groupId>
            <artifactId>jacoco-maven-plugin</artifactId>
            <version>0.8.11</version>
            <executions>
                <execution>
                    <goals>
                        <goal>prepare-agent</goal>
                    </goals>
                </execution>
                <execution>
                    <id>report</id>
                    <phase>test</phase>
                    <goals>
                        <goal>report</goal>
                    </goals>
                </execution>
            </executions>
        </plugin>
    </plugins>
</build>
```

Unit Test Example (Service Layer):
```java
// VoucherServiceTest.java
@ExtendWith(MockitoExtension.class)
class VoucherServiceTest {
    
    @Mock
    private VoucherRepository voucherRepository;
    
    @Mock
    private EventPublisher eventPublisher;
    
    @InjectMocks
    private VoucherService voucherService;
    
    @Test
    @DisplayName("Should create voucher successfully")
    void shouldCreateVoucherSuccessfully() {
        // Given
        CreateVoucherRequest request = CreateVoucherRequest.builder()
            .title("Test Voucher")
            .sellingPrice(new BigDecimal("10.00"))
            .quantity(100)
            .build();
            
        Voucher voucher = Voucher.builder()
            .id(UUID.randomUUID())
            .title(request.getTitle())
            .build();
            
        when(voucherRepository.save(any(Voucher.class))).thenReturn(voucher);
        
        // When
        VoucherDTO result = voucherService.createVoucher(request);
        
        // Then
        assertNotNull(result);
        assertEquals("Test Voucher", result.getTitle());
        verify(voucherRepository, times(1)).save(any(Voucher.class));
        verify(eventPublisher, times(1)).publishVoucherEvent(eq("voucher-events"), any());
    }
    
    @Test
    @DisplayName("Should throw exception when quantity is invalid")
    void shouldThrowExceptionWhenQuantityInvalid() {
        // Given
        CreateVoucherRequest request = CreateVoucherRequest.builder()
            .quantity(-1)
            .build();
            
        // When & Then
        assertThrows(InvalidRequestException.class, () -> {
            voucherService.createVoucher(request);
        });
        
        verify(voucherRepository, never()).save(any());
    }
}
```

Integration Test with TestContainers:
```java
// VoucherIntegrationTest.java
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@Testcontainers
@ActiveProfiles("test")
class VoucherIntegrationTest {
    
    @Container
    static PostgreSQLContainer<?> postgres = new PostgreSQLContainer<>("postgres:17")
        .withDatabaseName("kado24_test")
        .withUsername("test")
        .withPassword("test");
        
    @Container
    static KafkaContainer kafka = new KafkaContainer(
        DockerImageName.parse("confluentinc/cp-kafka:7.5.0")
    );
    
    @LocalServerPort
    private int port;
    
    @Autowired
    private VoucherRepository voucherRepository;
    
    @DynamicPropertySource
    static void setProperties(DynamicPropertyRegistry registry) {
        registry.add("spring.datasource.url", postgres::getJdbcUrl);
        registry.add("spring.datasource.username", postgres::getUsername);
        registry.add("spring.datasource.password", postgres::getPassword);
        registry.add("spring.kafka.bootstrap-servers", kafka::getBootstrapServers);
    }
    
    @BeforeEach
    void setUp() {
        voucherRepository.deleteAll();
        RestAssured.port = port;
    }
    
    @Test
    @DisplayName("Should create and retrieve voucher via API")
    void shouldCreateAndRetrieveVoucher() {
        // Given
        CreateVoucherRequest request = CreateVoucherRequest.builder()
            .title("Integration Test Voucher")
            .description("Test Description")
            .category("FOOD")
            .originalPrice(new BigDecimal("20.00"))
            .sellingPrice(new BigDecimal("15.00"))
            .quantity(50)
            .startDate(LocalDateTime.now())
            .endDate(LocalDateTime.now().plusDays(30))
            .build();
            
        // When - Create voucher
        String voucherId = given()
            .contentType(ContentType.JSON)
            .header("Authorization", "Bearer " + getTestToken())
            .body(request)
        .when()
            .post("/api/v1/vouchers")
        .then()
            .statusCode(201)
            .extract()
            .jsonPath()
            .getString("id");
            
        // Then - Retrieve voucher
        given()
            .contentType(ContentType.JSON)
        .when()
            .get("/api/v1/vouchers/{id}", voucherId)
        .then()
            .statusCode(200)
            .body("title", equalTo("Integration Test Voucher"))
            .body("sellingPrice", equalTo(15.00f));
    }
    
    private String getTestToken() {
        // Helper method to get test authentication token
        return "test-token";
    }
}
```

Repository Test:
```java
// VoucherRepositoryTest.java
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Testcontainers
class VoucherRepositoryTest {
    
    @Container
    static PostgreSQLContainer<?> postgres = new PostgreSQLContainer<>("postgres:17");
    
    @Autowired
    private VoucherRepository voucherRepository;
    
    @DynamicPropertySource
    static void setProperties(DynamicPropertyRegistry registry) {
        registry.add("spring.datasource.url", postgres::getJdbcUrl);
        registry.add("spring.datasource.username", postgres::getUsername);
        registry.add("spring.datasource.password", postgres::getPassword);
    }
    
    @Test
    @DisplayName("Should find active vouchers by category")
    void shouldFindActiveVouchersByCategory() {
        // Given
        Voucher voucher1 = createTestVoucher("Food Voucher 1", "FOOD", VoucherStatus.ACTIVE);
        Voucher voucher2 = createTestVoucher("Food Voucher 2", "FOOD", VoucherStatus.ACTIVE);
        Voucher voucher3 = createTestVoucher("Spa Voucher", "SPA", VoucherStatus.ACTIVE);
        
        voucherRepository.saveAll(List.of(voucher1, voucher2, voucher3));
        
        // When
        List<Voucher> results = voucherRepository.findByCategory AndStatus("FOOD", VoucherStatus.ACTIVE);
        
        // Then
        assertEquals(2, results.size());
        assertTrue(results.stream().allMatch(v -> v.getCategory().equals("FOOD")));
    }
    
    private Voucher createTestVoucher(String title, String category, VoucherStatus status) {
        return Voucher.builder()
            .id(UUID.randomUUID())
            .title(title)
            .category(category)
            .status(status)
            .sellingPrice(new BigDecimal("10.00"))
            .quantity(100)
            .build();
    }
}
```

Flutter Widget Test:
```dart
// login_screen_test.dart
void main() {
  group('LoginScreen Widget Tests', () {
    testWidgets('should display all UI elements', (WidgetTester tester) async {
      // Build the widget
      await tester.pumpWidget(
        MaterialApp(home: LoginScreen()),
      );
      
      // Verify elements are present
      expect(find.text('Login'), findsOneWidget);
      expect(find.byType(TextFormField), findsNWidgets(2)); // Email and password
      expect(find.byType(ElevatedButton), findsOneWidget);
      expect(find.text('Forgot Password?'), findsOneWidget);
    });
    
    testWidgets('should show validation error for invalid email', (WidgetTester tester) async {
      await tester.pumpWidget(
        MaterialApp(home: LoginScreen()),
      );
      
      // Enter invalid email
      await tester.enterText(find.byKey(Key('email_field')), 'invalid-email');
      await tester.tap(find.byType(ElevatedButton));
      await tester.pump();
      
      // Verify error message
      expect(find.text('Please enter a valid email'), findsOneWidget);
    });
    
    testWidgets('should call login on valid submission', (WidgetTester tester) async {
      final mockAuthBloc = MockAuthBloc();
      
      await tester.pumpWidget(
        MaterialApp(
          home: BlocProvider<AuthBloc>(
            create: (_) => mockAuthBloc,
            child: LoginScreen(),
          ),
        ),
      );
      
      // Enter valid credentials
      await tester.enterText(find.byKey(Key('email_field')), 'test@example.com');
      await tester.enterText(find.byKey(Key('password_field')), 'password123');
      await tester.tap(find.byType(ElevatedButton));
      await tester.pump();
      
      // Verify login was called
      verify(mockAuthBloc.add(any)).called(1);
    });
  });
}
```

E2E Test Example (Postman/Newman):
```json
{
  "name": "Kado24 E2E Tests",
  "item": [
    {
      "name": "Complete Purchase Flow",
      "item": [
        {
          "name": "1. Login",
          "request": {
            "method": "POST",
            "url": "{{base_url}}/oauth2/login",
            "body": {
              "mode": "raw",
              "raw": "{\"username\":\"test@example.com\",\"password\":\"Test123!\"}"
            }
          },
          "event": [
            {
              "listen": "test",
              "script": {
                "exec": [
                  "pm.test(\"Login successful\", function () {",
                  "    pm.response.to.have.status(200);",
                  "    var jsonData = pm.response.json();",
                  "    pm.expect(jsonData).to.have.property('accessToken');",
                  "    pm.environment.set(\"access_token\", jsonData.accessToken);",
                  "});"
                ]
              }
            }
          ]
        },
        {
          "name": "2. Browse Vouchers",
          "request": {
            "method": "GET",
            "url": "{{base_url}}/api/v1/vouchers?page=1&size=10",
            "header": [
              {
                "key": "Authorization",
                "value": "Bearer {{access_token}}"
              }
            ]
          },
          "event": [
            {
              "listen": "test",
              "script": {
                "exec": [
                  "pm.test(\"Vouchers retrieved\", function () {",
                  "    pm.response.to.have.status(200);",
                  "    var jsonData = pm.response.json();",
                  "    pm.expect(jsonData.content).to.be.an('array');",
                  "    if (jsonData.content.length > 0) {",
                  "        pm.environment.set(\"voucher_id\", jsonData.content[0].id);",
                  "    }",
                  "});"
                ]
              }
            }
          ]
        },
        {
          "name": "3. Create Order",
          "request": {
            "method": "POST",
            "url": "{{base_url}}/api/v1/orders",
            "header": [
              {
                "key": "Authorization",
                "value": "Bearer {{access_token}}"
              }
            ],
            "body": {
              "mode": "raw",
              "raw": "{\"voucherId\":\"{{voucher_id}}\",\"quantity\":1}"
            }
          },
          "event": [
            {
              "listen": "test",
              "script": {
                "exec": [
                  "pm.test(\"Order created\", function () {",
                  "    pm.response.to.have.status(201);",
                  "    var jsonData = pm.response.json();",
                  "    pm.environment.set(\"order_id\", jsonData.orderId);",
                  "});"
                ]
              }
            }
          ]
        }
      ]
    }
  ]
}
```

Performance Test (using JMeter or Gatling):
```scala
// VoucherLoadTest.scala
import io.gatling.core.Predef._
import io.gatling.http.Predef._
import scala.concurrent.duration._

class VoucherLoadTest extends Simulation {
  
  val httpProtocol = http
    .baseUrl("http://localhost:9080")
    .acceptHeader("application/json")
    .contentTypeHeader("application/json")
    
  val scn = scenario("Voucher Browse Load Test")
    .exec(http("Get Vouchers")
      .get("/api/v1/vouchers?page=1&size=20")
      .check(status.is(200))
    )
    .pause(1)
    .exec(http("Get Voucher Detail")
      .get("/api/v1/vouchers/${voucherId}")
      .check(status.is(200))
    )
    
  setUp(
    scn.inject(
      rampUsersPerSec(10) to 100 during (60 seconds),
      constantUsersPerSec(100) during (5 minutes)
    )
  ).protocols(httpProtocol)
   .assertions(
     global.responseTime.max.lt(5000),
     global.successfulRequests.percent.gt(95)
   )
}
```

Testing Best Practices:
1. Follow AAA pattern (Arrange, Act, Assert)
2. Use meaningful test names
3. Test both happy path and edge cases
4. Mock external dependencies
5. Use TestContainers for integration tests
6. Maintain >80% code coverage
7. Run tests in CI/CD pipeline
8. Separate unit, integration, and E2E tests
```

---

## PHASE 6: Production Deployment

### Prompt 6.1: Kubernetes Deployment
```
Create production-ready Kubernetes manifests for Kado24 platform:

Directory Structure:
kubernetes/
├── namespaces/
│   └── kado24-namespace.yaml
├── config/
│   ├── configmaps.yaml
│   └── secrets.yaml
├── deployments/
│   ├── auth-service.yaml
│   ├── user-service.yaml
│   ├── voucher-service.yaml
│   ├── order-service.yaml
│   └── ... (all microservices)
├── services/
│   ├── auth-service-svc.yaml
│   └── ... (all services)
├── ingress/
│   └── api-ingress.yaml
├── statefulsets/
│   ├── postgres.yaml
│   ├── redis.yaml
│   └── kafka.yaml
├── hpa/
│   └── microservices-hpa.yaml
└── monitoring/
    ├── prometheus.yaml
    └── grafana.yaml

Namespace:
```yaml
# namespaces/kado24-namespace.yaml
apiVersion: v1
kind: Namespace
metadata:
  name: kado24-prod
  labels:
    name: kado24-prod
    environment: production
```

ConfigMap:
```yaml
# config/configmaps.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: kado24-config
  namespace: kado24-prod
data:
  POSTGRES_HOST: "postgres-service"
  POSTGRES_PORT: "5432"
  POSTGRES_DB: "kado24_db"
  REDIS_HOST: "redis-service"
  REDIS_PORT: "6379"
  KAFKA_BOOTSTRAP_SERVERS: "kafka-service:9092"
  SPRING_PROFILES_ACTIVE: "production"
```

Secrets:
```yaml
# config/secrets.yaml
apiVersion: v1
kind: Secret
metadata:
  name: kado24-secrets
  namespace: kado24-prod
type: Opaque
data:
  POSTGRES_PASSWORD: <base64-encoded-password>
  JWT_SECRET: <base64-encoded-jwt-secret>
  ABA_API_KEY: <base64-encoded-key>
  WING_API_KEY: <base64-encoded-key>
```

Deployment Example (Auth Service):
```yaml
# deployments/auth-service.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: auth-service
  namespace: kado24-prod
  labels:
    app: auth-service
    tier: backend
spec:
  replicas: 3
  strategy:
    type: RollingUpdate
    rollingUpdate:
      maxSurge: 1
      maxUnavailable: 0
  selector:
    matchLabels:
      app: auth-service
  template:
    metadata:
      labels:
        app: auth-service
        version: v1
    spec:
      containers:
      - name: auth-service
        image: kado24/auth-service:latest
        imagePullPolicy: Always
        ports:
        - containerPort: 8081
          name: http
        env:
        - name: SERVER_PORT
          value: "8081"
        - name: POSTGRES_HOST
          valueFrom:
            configMapKeyRef:
              name: kado24-config
              key: POSTGRES_HOST
        - name: POSTGRES_PASSWORD
          valueFrom:
            secretKeyRef:
              name: kado24-secrets
              key: POSTGRES_PASSWORD
        - name: JWT_SECRET
          valueFrom:
            secretKeyRef:
              name: kado24-secrets
              key: JWT_SECRET
        resources:
          requests:
            memory: "512Mi"
            cpu: "250m"
          limits:
            memory: "1Gi"
            cpu: "500m"
        livenessProbe:
          httpGet:
            path: /actuator/health/liveness
            port: 8081
          initialDelaySeconds: 60
          periodSeconds: 10
          timeoutSeconds: 5
          failureThreshold: 3
        readinessProbe:
          httpGet:
            path: /actuator/health/readiness
            port: 8081
          initialDelaySeconds: 30
          periodSeconds: 5
          timeoutSeconds: 3
          failureThreshold: 3
---
apiVersion: v1
kind: Service
metadata:
  name: auth-service
  namespace: kado24-prod
spec:
  type: ClusterIP
  selector:
    app: auth-service
  ports:
  - port: 8081
    targetPort: 8081
    protocol: TCP
    name: http
```

Horizontal Pod Autoscaler:
```yaml
# hpa/microservices-hpa.yaml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: auth-service-hpa
  namespace: kado24-prod
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: auth-service
  minReplicas: 2
  maxReplicas: 10
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
  - type: Resource
    resource:
      name: memory
      target:
        type: Utilization
        averageUtilization: 80
  behavior:
    scaleUp:
      stabilizationWindowSeconds: 60
      policies:
      - type: Percent
        value: 50
        periodSeconds: 60
    scaleDown:
      stabilizationWindowSeconds: 300
      policies:
      - type: Percent
        value: 25
        periodSeconds: 60
```

Ingress:
```yaml
# ingress/api-ingress.yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: kado24-ingress
  namespace: kado24-prod
  annotations:
    nginx.ingress.kubernetes.io/rewrite-target: /
    nginx.ingress.kubernetes.io/ssl-redirect: "true"
    cert-manager.io/cluster-issuer: "letsencrypt-prod"
spec:
  ingressClassName: nginx
  tls:
  - hosts:
    - api.kado24.com
    secretName: kado24-tls
  rules:
  - host: api.kado24.com
    http:
      paths:
      - path: /oauth2
        pathType: Prefix
        backend:
          service:
            name: auth-service
            port:
              number: 8081
      - path: /api/v1/users
        pathType: Prefix
        backend:
          service:
            name: user-service
            port:
              number: 8082
      - path: /api/v1/vouchers
        pathType: Prefix
        backend:
          service:
            name: voucher-service
            port:
              number: 8083
```

PostgreSQL StatefulSet:
```yaml
# statefulsets/postgres.yaml
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: postgres
  namespace: kado24-prod
spec:
  serviceName: postgres-service
  replicas: 1
  selector:
    matchLabels:
      app: postgres
  template:
    metadata:
      labels:
        app: postgres
    spec:
      containers:
      - name: postgres
        image: postgres:17
        ports:
        - containerPort: 5432
          name: postgres
        env:
        - name: POSTGRES_DB
          valueFrom:
            configMapKeyRef:
              name: kado24-config
              key: POSTGRES_DB
        - name: POSTGRES_PASSWORD
          valueFrom:
            secretKeyRef:
              name: kado24-secrets
              key: POSTGRES_PASSWORD
        volumeMounts:
        - name: postgres-storage
          mountPath: /var/lib/postgresql/data
        resources:
          requests:
            memory: "2Gi"
            cpu: "1000m"
          limits:
            memory: "4Gi"
            cpu: "2000m"
  volumeClaimTemplates:
  - metadata:
      name: postgres-storage
    spec:
      accessModes: [ "ReadWriteOnce" ]
      resources:
        requests:
          storage: 50Gi
```

Deployment Script:
```bash
#!/bin/bash
# deploy.sh

set -e

NAMESPACE="kado24-prod"
CONTEXT="production-cluster"

echo "Deploying Kado24 to production..."

# Set context
kubectl config use-context $CONTEXT

# Create namespace
kubectl apply -f namespaces/kado24-namespace.yaml

# Apply configurations
kubectl apply -f config/configmaps.yaml
kubectl apply -f config/secrets.yaml

# Deploy stateful services
kubectl apply -f statefulsets/

# Wait for databases to be ready
kubectl wait --for=condition=ready pod -l app=postgres -n $NAMESPACE --timeout=300s
kubectl wait --for=condition=ready pod -l app=redis -n $NAMESPACE --timeout=300s

# Deploy microservices
kubectl apply -f deployments/
kubectl apply -f services/

# Wait for deployments
kubectl rollout status deployment/auth-service -n $NAMESPACE
kubectl rollout status deployment/user-service -n $NAMESPACE
kubectl rollout status deployment/voucher-service -n $NAMESPACE
# ... wait for all services

# Apply HPA
kubectl apply -f hpa/

# Apply Ingress
kubectl apply -f ingress/

# Verify deployment
kubectl get all -n $NAMESPACE

echo "Deployment completed successfully!"
```

Monitoring with Prometheus:
```yaml
# monitoring/prometheus.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: prometheus-config
  namespace: kado24-prod
data:
  prometheus.yml: |
    global:
      scrape_interval: 15s
    scrape_configs:
      - job_name: 'kado24-services'
        kubernetes_sd_configs:
        - role: pod
          namespaces:
            names:
            - kado24-prod
        relabel_configs:
        - source_labels: [__meta_kubernetes_pod_label_app]
          action: keep
          regex: .*-service
        - source_labels: [__meta_kubernetes_pod_annotation_prometheus_io_scrape]
          action: keep
          regex: true
        - source_labels: [__meta_kubernetes_pod_annotation_prometheus_io_path]
          action: replace
          target_label: __metrics_path__
          regex: (.+)
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: prometheus
  namespace: kado24-prod
spec:
  replicas: 1
  selector:
    matchLabels:
      app: prometheus
  template:
    metadata:
      labels:
        app: prometheus
    spec:
      containers:
      - name: prometheus
        image: prom/prometheus:latest
        args:
          - '--config.file=/etc/prometheus/prometheus.yml'
          - '--storage.tsdb.path=/prometheus'
        ports:
        - containerPort: 9090
        volumeMounts:
        - name: config
          mountPath: /etc/prometheus
        - name: storage
          mountPath: /prometheus
      volumes:
      - name: config
        configMap:
          name: prometheus-config
      - name: storage
        emptyDir: {}
```

Best Practices:
- Use namespaces for isolation
- Set resource requests and limits
- Implement health checks (liveness, readiness)
- Use HPA for auto-scaling
- Implement proper monitoring
- Use secrets for sensitive data
- Enable TLS for all external traffic
- Implement network policies
- Regular backups of stateful data
- Blue-green or canary deployments
```

---

## Summary & Best Practices

### Development Workflow
1. Start with backend services (auth → core → business logic)
2. Develop mobile apps in parallel with backend
3. Admin portal after core features are stable
4. Integrate external services last
5. Comprehensive testing at each phase
6. Deploy to staging before production

### Code Quality Standards
- Follow SOLID principles
- Write comprehensive tests (>80% coverage)
- Document all public APIs
- Use consistent naming conventions
- Implement proper error handling
- Log all important events
- Monitor performance metrics

### Security Best Practices
- HTTPS everywhere
- OAuth2 for authentication
- Never store sensitive data in logs
- Implement rate limiting
- Validate all inputs
- Use prepared statements (prevent SQL injection)
- Regular security audits
- Keep dependencies updated

### Performance Optimization
- Database indexing
- Caching with Redis
- Asynchronous processing with Kafka
- Connection pooling
- Query optimization
- CDN for static assets
- Horizontal scaling

### Monitoring & Observability
- Centralized logging (ELK stack)
- Metrics collection (Prometheus)
- Dashboards (Grafana)
- Alerting for critical issues
- Distributed tracing
- Error tracking (Sentry)

---

## Quick Reference

### Key Technologies
- **Backend**: Spring Boot 3.2, Java 17, Maven
- **Database**: PostgreSQL 17, Redis 7
- **Messaging**: Apache Kafka 3.x
- **API Gateway**: Apache APISIX 3.7
- **Mobile**: Flutter 3.x
- **Admin**: Angular 17
- **Infrastructure**: Docker, Kubernetes
- **Monitoring**: Prometheus, Grafana

### Important Ports
- Auth Service: 8081
- User Service: 8082
- Voucher Service: 8083
- Order Service: 8084
- Payment Service: 8085
- Wallet Service: 8086
- Redemption Service: 8087
- Merchant Service: 8088
- Admin Backend: 8089
- API Gateway: 9080
- PostgreSQL: 5432
- Redis: 6379
- Kafka: 9092

### Common Commands

**Maven:**
```bash
mvn clean install
mvn spring-boot:run
mvn test
mvn package -DskipTests
```

**Docker:**
```bash
docker-compose up -d
docker-compose logs -f <service>
docker-compose down
```

**Flutter:**
```bash
flutter pub get
flutter run
flutter build apk --release
flutter test
```

**Kubernetes:**
```bash
kubectl apply -f <file>
kubectl get pods -n kado24-prod
kubectl logs -f <pod-name>
kubectl describe pod <pod-name>
kubectl rollout restart deployment/<name>
```

---

**End of Development Guide**

This comprehensive guide provides everything needed to develop the Kado24 platform from scratch using Cursor AI. Follow each phase sequentially for best results.
